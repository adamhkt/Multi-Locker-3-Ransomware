<?php
mysql_connect($Host,$User,$Password)or die(mysql_error());
mysql_select_db($DbName)or die(mysql_error());
mysql_query("SET NAMES CP1251");

?>
