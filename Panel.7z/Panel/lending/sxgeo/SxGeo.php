<?php
/***************************************************************************\
| Sypex Geo                  version 2.0.0                                  |
| (c)2009 zapimir            zapimir@zapimir.net       http://sypex.net/    |
| (c)2009 BINOVATOR          info@sypex.net                                 |
|---------------------------------------------------------------------------|
|     created: 2006.10.17 18:33              modified: 2012.02.13 04:10     |
|---------------------------------------------------------------------------|
| Sypex Geo is released under the terms of the BSD license                  |
|   http://sypex.net/bsd_license.txt                                        |
\***************************************************************************/

define('SXGEO_FILE', 0);
define('SXGEO_MEMORY', 1);
define('SXGEO_BATCH', 2);

class SxGeo {
	var $fh;
	var $info;
	var $index;
	var $num2cc;
	var $database;

	function SxGeo($filename = 'sxgeo/SxGeo.dat', $type = SXGEO_FILE){
		$this->fh   = fopen($filename, 'rb');
		$head = fread($this->fh, 12);
		if(substr($head, 0, 3) != 'SxG') die("Can't open {$filename}\n");
		$this->info = unpack('Cver/Cflags/Cidx_len/nrange/Nitems', substr($head, 3));
		if($this->info['idx_len'] == 0 || $this->info['idx_len'] == 0 || $this->info['items'] == 0) die("Can't open {$filename}\n");
		$this->idx   = fread($this->fh, 224 * 4);
		$this->index = fread($this->fh, ($this->info['idx_len']) * 4);

		$this->info['db_begin'] = ftell($this->fh);
		if ($type & SXGEO_BATCH) {
			$this->blocks = array();
			for($i = 0; $i < 224; $i++){
				$b = unpack("Npos", substr($this->idx, $i*4, 4));
				$this->blocks[$i]  = $b['pos'];
			}
			unset ($this->idx);
			$this->index_a = array();
			for($i = 0; $i < $this->info['idx_len']; $i++){
				$b = substr($this->index, $i*4, 4);
				$this->index_a[$i]  = $b;
			}
			unset ($this->index);
		}
		if ($type & SXGEO_MEMORY) {
			$this->database  = fread($this->fh, $this->info['items'] * 4);
			fclose($this->fh);
		}
		$this->info['type'] = $type;
		$this->num2cc = array(
			'', 'AP', 'EU', 'AD', 'AE', 'AF', 'AG', 'AI', 'AL', 'AM', 'AN', 'AO', 'AQ',
			'AR', 'AS', 'AT', 'AU', 'AW', 'AZ', 'BA', 'BB', 'BD', 'BE', 'BF', 'BG', 'BH',
			'BI', 'BJ', 'BM', 'BN', 'BO', 'BR', 'BS', 'BT', 'BV', 'BW', 'BY', 'BZ', 'CA',
			'CC', 'CD', 'CF', 'CG', 'CH', 'CI', 'CK', 'CL', 'CM', 'CN', 'CO', 'CR', 'CU',
			'CV', 'CX', 'CY', 'CZ', 'DE', 'DJ', 'DK', 'DM', 'DO', 'DZ', 'EC', 'EE', 'EG',
			'EH', 'ER', 'ES', 'ET', 'FI', 'FJ', 'FK', 'FM', 'FO', 'FR', 'FX', 'GA', 'GB',
			'GD', 'GE', 'GF', 'GH', 'GI', 'GL', 'GM', 'GN', 'GP', 'GQ', 'GR', 'GS', 'GT',
			'GU', 'GW', 'GY', 'HK', 'HM', 'HN', 'HR', 'HT', 'HU', 'ID', 'IE', 'IL', 'IN',
			'IO', 'IQ', 'IR', 'IS', 'IT', 'JM', 'JO', 'JP', 'KE', 'KG', 'KH', 'KI', 'KM',
			'KN', 'KP', 'KR', 'KW', 'KY', 'KZ', 'LA', 'LB', 'LC', 'LI', 'LK', 'LR', 'LS',
			'LT', 'LU', 'LV', 'LY', 'MA', 'MC', 'MD', 'MG', 'MH', 'MK', 'ML', 'MM', 'MN',
			'MO', 'MP', 'MQ', 'MR', 'MS', 'MT', 'MU', 'MV', 'MW', 'MX', 'MY', 'MZ', 'NA',
			'NC', 'NE', 'NF', 'NG', 'NI', 'NL', 'NO', 'NP', 'NR', 'NU', 'NZ', 'OM', 'PA',
			'PE', 'PF', 'PG', 'PH', 'PK', 'PL', 'PM', 'PN', 'PR', 'PS', 'PT', 'PW', 'PY',
			'QA', 'RE', 'RO', 'RU', 'RW', 'SA', 'SB', 'SC', 'SD', 'SE', 'SG', 'SH', 'SI',
			'SJ', 'SK', 'SL', 'SM', 'SN', 'SO', 'SR', 'ST', 'SV', 'SY', 'SZ', 'TC', 'TD',
			'TF', 'TG', 'TH', 'TJ', 'TK', 'TM', 'TN', 'TO', 'TL', 'TR', 'TT', 'TV', 'TW',
			'TZ', 'UA', 'UG', 'UM', 'US', 'UY', 'UZ', 'VA', 'VC', 'VE', 'VG', 'VI', 'VN',
			'VU', 'WF', 'WS', 'YE', 'YT', 'RS', 'ZA', 'ZM', 'ME', 'ZW', 'A1', 'A2', 'O1',
			'AX', 'GG', 'IM', 'JE', 'BL', 'MF'
		);
	}

	function search_idx($ipn, $min, $max){
		if($max - $min <= 1) return $min;
		if($max >= $this->info['idx_len']) $max = $this->info['idx_len']-1;
		if($this->info['type'] & SXGEO_BATCH){
			while($max - $min > 5){
				$offset = ($min + $max) >> 1;
				if ($ipn > $this->index_a[$offset]) $min = $offset;
				else $max = $offset;
			}
			while ($ipn > $this->index_a[$min] && ++$min <= $max){};
		}
		else {
			while($max - $min > 5){
				$offset = ($min + $max) >> 1;
				if ($ipn > substr($this->index, $offset*4, 4)) $min = $offset;
				else $max = $offset;
			}
			while ($ipn > substr($this->index, $min*4, 4) && ++$min <= $max){};
		}
		return  $min;
	}

	function search_db($str, $ipn, $min, $max){
		$ipn = substr($ipn, 1);
		if($max - $min == 1) return ord(substr($str, $min * 4 + 3 , 1));
		while($max - $min > 7){
			$offset = ($min + $max) >> 1;
			if ($ipn > substr($str, $offset*4, 3)) $min = $offset;
			else $max = $offset;
		}
		while ($ipn >= substr($str, $min*4, 3) && ++$min < $max){};
		return ord(substr($str, $min * 4 - 1, 1));
	}

	function get_num($ip){
		$ipn = pack('N', ip2long($ip));
		$ip1 = (int)$ip; // Первый байт
		if($ip1 == 0 || $ip1 == 10 || $ip1 == 127 || $ip1 > 223) return 0;
		$this->ip1c = pack('C', $ip1);
		// Находим блок данных
		if ($this->info['type'] & SXGEO_BATCH){
			$blocks = array('min' => $this->blocks[$ip1-1], 'max' => $this->blocks[$ip1]);
		}
		else {
			$blocks = unpack("Nmin/Nmax", substr($this->idx, ($ip1 - 1) * 4, 8));
		}
		$part = $this->search_idx($ipn, floor($blocks['min'] / $this->info['range']), ceil($blocks['max'] / $this->info['range']));
		// Нашли номер блока в котором нужно искать IP, теперь находим нужный блок в БД
		$min = $part > 0 ? $part * $this->info['range'] : 0;
		$max = $part > $this->info['idx_len'] ? $this->info['items'] : ($part+1) * $this->info['range'];
		// Нужно проверить чтобы блок не выходил за пределы блока первого байта
		if($min < $blocks['min']) $min = $blocks['min'];
		if($max > $blocks['max']) $max = $blocks['max'];
		$len = $max - $min;
		// Находим нужный диапазон в БД
		if ($this->info['type'] & SXGEO_MEMORY) {
			return $this->search_db($this->database, $ipn, $min, $max);
		}
		else {
			fseek($this->fh, $this->info['db_begin'] + $min*4);
			return $this->search_db(fread($this->fh, $len*4), $ipn, 0, $len);
		}
	}

	function get_cc($ip){
		return $this->num2cc[$this->get_num($ip)];
	}

	function close(){
		if(!$this->info['type'] & SXGEO_MEMORY) fclose($this->fh);
		unset($this->info);
		unset($this->index);
		unset($this->num2cc);
		unset($this->database);
	}
}

?>