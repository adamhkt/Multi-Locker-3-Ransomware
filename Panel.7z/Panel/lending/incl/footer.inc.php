<?php

list($seconds, $microseconds) = explode(" ", microtime());
$time_end = $seconds + $microseconds;
$total_time = round($time_end-$time_start, 4);

print "<br /><br />";
print "<table class='bottom' cellpadding=0 cellspacing=0>";

  print "<tr><td align='center'>This page was produced in $total_time seconds.</td></tr>";
print "</table>";

print "<br /><br />";

print "</center>";
print "</body>";
print "</html>";

?>