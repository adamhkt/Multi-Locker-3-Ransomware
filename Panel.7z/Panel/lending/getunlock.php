<?php
include 'include/config.php';
include 'include/db.php';
$ip = mysql_escape_string($_SERVER['REMOTE_ADDR']);

$result = mysql_query("SELECT * FROM billing WHERE ip='".$ip."' ");

if (mysql_num_rows($result)>0) 
{
	$item = mysql_fetch_array($result);
	if($item['go']=='true')
		echo 'OK';
	else
		echo 'FUCK';
}
else 
	echo 'FUCK';
		

mysql_query("UPDATE billing SET go='' WHERE ip='".$ip."'") or die (mysql_error());
?>
